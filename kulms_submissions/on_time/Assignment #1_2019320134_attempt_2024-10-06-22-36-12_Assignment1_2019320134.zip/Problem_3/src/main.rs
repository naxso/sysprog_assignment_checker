use std::io;

const MAX: usize = 19;
fn main() {
    // 오목 판 준비
    let mut board = [[0; MAX]; MAX];
    let mut line: String = String::new();
    let mut row: Vec<i32>;

    // 오목 판 입력 받기
    for i in 0..MAX {
        line.clear();
        io::stdin().read_line(&mut line).expect("get rows");
        row = line
            .trim()
            .split_whitespace()
            .map(|s| s.parse::<i32>().expect("msg"))
            .collect();

        for j in 0..MAX {
            board[i][j] = row[j];
        }
    }

    // 오목 판 순회하면서 오목 성공 여부 확인
    for i in 0..MAX {
        for j in 0..MAX {
            if board[i][j] != 0 {
                if check_omok(&board, i, j) != 0 {
                    println!("{}", board[i][j]);
                    println!("{} {}", i + 1, j + 1);
                    return;
                }
            } else {
                continue;
            }
        }
    }

    println!("0");

    return;
}

// 오목 여부 확인 함수
fn check_omok(board: &[[i32; MAX]; MAX], row: usize, col: usize) -> i32 {
    let move_arr: [[i32; 2]; 4] = [[1, 0], [1, 1], [0, 1], [-1, 1]];

    // 좌상단에서 우하단으로 내려가면서 오목이 나올 수 있는 방향 체크
    // usize 타입 때문에 index가 증가하는 경우와 감소하는 경우를 나눠서 체크
    'check_direction: for k in 0..move_arr.len() {
        let mut cnt = 1;

        if move_arr[k][0] < 0 {
            let i = move_arr[k][0].abs() as usize;
            let j = move_arr[k][1] as usize;

            // 원래는 row - i * cnt >= 0 을 조건으로 사용하려 했는데, usize 타입에서는 0보다 작아지면 underflow가 발생 -> 음수가 나올 수가 없음.
            while (row >= i * cnt)
                && (col + j * cnt < MAX)
                && (board[row][col] == board[row - i * cnt][col + j * cnt])
            {
                if cnt > 4 {
                    // 육목 이상인 경우
                    continue 'check_direction;
                }
                cnt += 1
            }

            // 반대 쪽에 같은 색의 돌이 있는지 육목 확인 필요
            if cnt == 5 {
                if row < MAX - i && col >= j && board[row][col] == board[row + i][col - j] {
                    continue 'check_direction;
                }
                return board[row][col];
            }
        } else {
            let i = move_arr[k][0] as usize;
            let j = move_arr[k][1] as usize;

            while (row + i * cnt < MAX)
                && (col + j * cnt < MAX)
                && (board[row][col] == board[row + i * cnt][col + j * cnt])
            {
                if cnt > 4 {
                    // 육목 이상인 경우
                    continue 'check_direction;
                }
                cnt += 1;
            }

            // 반대 쪽에 같은 색의 돌이 있는지 육목 확인 필요
            if cnt == 5 {
                if row >= i && col >= j && board[row][col] == board[row - i][col - j] {
                    continue 'check_direction;
                }
                return board[row][col];
            }
        }
    }

    // 각 방향에 오목이 없으면, return 0
    return 0;
}
