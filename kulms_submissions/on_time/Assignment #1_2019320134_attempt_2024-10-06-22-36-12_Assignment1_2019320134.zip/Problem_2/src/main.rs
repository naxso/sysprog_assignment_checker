use std::io;
fn main() {
    let mut line: String = String::new(); // input 받을 변수
    let mut cmd_vec: Vec<String> = Vec::new(); // 계산기 명령어 벡터
    let mut num_stack: Vec<i32> = Vec::new(); // 숫자 담을 벡터
    let mut output_vec: Vec<String> = Vec::new(); // 출력 담을 벡터
    let err_msg = String::from("ERROR"); // 에러 메시지 string

    // 전체 계산기 프로그램 loop
    'program: loop {
        // 계산 내용 커맨드 입력 loop
        'get_cmd: loop {
            line.clear();
            io::stdin().read_line(&mut line).expect("get command");

            match line.split_whitespace().next() {
                Some("POP") => cmd_vec.push(line.clone()),
                Some("INV") => cmd_vec.push(line.clone()),
                Some("DUP") => cmd_vec.push(line.clone()),
                Some("SWP") => cmd_vec.push(line.clone()),
                Some("ADD") => cmd_vec.push(line.clone()),
                Some("SUB") => cmd_vec.push(line.clone()),
                Some("MUL") => cmd_vec.push(line.clone()),
                Some("DIV") => cmd_vec.push(line.clone()),
                Some("MOD") => cmd_vec.push(line.clone()),
                Some("NUM") => cmd_vec.push(line.clone()),
                Some("END") => break 'get_cmd,
                Some("QUIT") => break 'program,
                _ => (),
            }
        }

        // 계산 횟수 입력
        line.clear();
        io::stdin().read_line(&mut line).expect("get num_count");
        let num_count = line
            .trim()
            .parse()
            .expect("should be integer for num_count");

        // 실제 계산 loop
        'calculate: for _ in 0..num_count {
            // 초깃값 입력
            line.clear();
            io::stdin().read_line(&mut line).expect("get_starting_num");

            match line.trim().parse::<i32>() {
                Ok(n) if n.abs() <= 10_i32.pow(9) => {
                    num_stack.clear();
                    num_stack.push(n);
                }
                _ => {
                    output_vec.push(err_msg.clone());
                    continue 'calculate;
                }
            };

            for cmd in cmd_vec.iter() {
                // NUM 명령어를 위한 split
                let mut splitted_cmd = cmd.split_whitespace();
                match splitted_cmd.next() {
                    Some("POP") => match num_stack.pop() {
                        Some(_) => continue,
                        None => {
                            output_vec.push(err_msg.clone());
                            continue 'calculate;
                        }
                    },
                    Some("INV") => {
                        match num_stack.pop() {
                            Some(n) => match n.checked_mul(-1) {
                                Some(result) => num_stack.push(result),
                                None => {
                                    output_vec.push(err_msg.clone());
                                    continue 'calculate;
                                }
                            },
                            None => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("DUP") => match num_stack.last() {
                        Some(n) => num_stack.push(n.clone()),
                        None => {
                            output_vec.push(err_msg.clone());
                            continue 'calculate;
                        }
                    },
                    Some("SWP") => {
                        match pop_two_items(&mut num_stack) {
                            Ok((fir, sec)) => {
                                num_stack.push(fir);
                                num_stack.push(sec);
                            }
                            Err(_) => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("ADD") => {
                        match pop_two_items(&mut num_stack) {
                            Ok((fir, sec)) => match sec.checked_add(fir) {
                                Some(result) if result.abs() <= 10_i32.pow(9) => {
                                    num_stack.push(result)
                                }
                                _ => {
                                    output_vec.push(err_msg.clone());
                                    continue 'calculate;
                                }
                            },
                            Err(_) => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("SUB") => {
                        match pop_two_items(&mut num_stack) {
                            Ok((fir, sec)) => match sec.checked_sub(fir) {
                                Some(result) if result.abs() <= 10_i32.pow(9) => {
                                    num_stack.push(result)
                                }
                                _ => {
                                    output_vec.push(err_msg.clone());
                                    continue 'calculate;
                                }
                            },
                            Err(_) => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("MUL") => {
                        match pop_two_items(&mut num_stack) {
                            Ok((fir, sec)) => match sec.checked_mul(fir) {
                                Some(result) if result.abs() <= 10_i32.pow(9) => {
                                    num_stack.push(result)
                                }
                                _ => {
                                    output_vec.push(err_msg.clone());
                                    continue 'calculate;
                                }
                            },
                            Err(_) => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("DIV") => {
                        match pop_two_items(&mut num_stack) {
                            Ok((fir, sec)) => match sec.checked_div(fir) {
                                Some(result) if result.abs() <= 10_i32.pow(9) => {
                                    num_stack.push(result)
                                }
                                _ => {
                                    output_vec.push(err_msg.clone());
                                    continue 'calculate;
                                }
                            },
                            Err(_) => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("MOD") => {
                        match pop_two_items(&mut num_stack) {
                            Ok((fir, sec)) => match sec.checked_rem(fir) {
                                Some(result) if result.abs() <= 10_i32.pow(9) => {
                                    num_stack.push(result)
                                }
                                _ => {
                                    output_vec.push(err_msg.clone());
                                    continue 'calculate;
                                }
                            },
                            Err(_) => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        };
                    }
                    Some("NUM") => match splitted_cmd.next() {
                        Some(s) => match s.trim().parse::<i32>() {
                            Ok(n) if n.abs() <= 10_i32.pow(9) => num_stack.push(n),
                            _ => {
                                output_vec.push(err_msg.clone());
                                continue 'calculate;
                            }
                        },
                        None => {
                            output_vec.push(err_msg.clone());
                            continue 'calculate;
                        }
                    },
                    _ => {
                        output_vec.push(err_msg.clone());
                        continue 'calculate;
                    }
                }
            }

            // 계산 결과 확인
            match num_stack.pop() {
                Some(num) if num_stack.is_empty() => {
                    output_vec.push(num.to_string());
                }
                _ => output_vec.push(err_msg.clone()),
            };
        }
        output_vec.push("".to_string());
        cmd_vec.clear();
    }

    // 최종 결과 출력
    for msg in output_vec {
        println!("{msg}");
    }
}

// 스택에서 item 두 개씩 pop하는 함수
fn pop_two_items(stk: &mut Vec<i32>) -> Result<(i32, i32), ()> {
    let fir: i32 = match stk.pop() {
        Some(n) => n,
        None => return Err(()),
    };

    let sec: i32 = match stk.pop() {
        Some(n) => n,
        None => return Err(()),
    };

    return Ok((fir, sec));
}
