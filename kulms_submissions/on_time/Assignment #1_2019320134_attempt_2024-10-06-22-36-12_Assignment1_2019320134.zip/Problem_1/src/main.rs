use std::io;

fn main() {
    let mut time_sum: i32 = 0;
    let mut grade_sum: f32 = 0.0;

    // 강의 수와 학점 커트 라인 입력
    let mut splitted_line = get_splitted_line();
    let course_num: i32 = splitted_line[0]
        .trim()
        .parse()
        .expect("should be integer for course_num");
    let cut_line: f32 = splitted_line[1]
        .trim()
        .parse::<f32>()
        .expect("should be float for cut_line")
        + 0.01;

    for i in 0..course_num {
        splitted_line = get_splitted_line();
        let time: i32 = splitted_line[0]
            .trim()
            .parse()
            .expect("should be integer for course time");
        time_sum += time;

        // 강의 수보다 하나 적을 때 까지는 시수와 받은 학점 입력
        if i < course_num - 1 {
            let grade = splitted_line[1].trim();
            let grade_num: f32 = match grade {
                "A+" => 4.5,
                "A0" => 4.0,
                "B+" => 3.5,
                "B0" => 3.0,
                "C+" => 2.5,
                "C0" => 2.0,
                "D+" => 1.5,
                "D0" => 1.0,
                "F" => 0.0,
                _ => panic!("invalid grade"),
            };

            grade_sum += time as f32 * grade_num;
        } else {
            // 마지막 강의는 시수만 받아서 필요한 학점 계산
            match dump_three_decimal((cut_line * time_sum as f32 - grade_sum) / time as f32) {
                g if g > 4.5 => println!("impossible"),
                g if g > 4.0 => println!("A+"),
                g if g > 3.5 => println!("A0"),
                g if g > 3.0 => println!("B+"),
                g if g > 2.5 => println!("B0"),
                g if g > 2.0 => println!("C+"),
                g if g > 1.5 => println!("C0"),
                g if g > 1.0 => println!("D+"),
                g if g > 0.0 => println!("D0"),
                _ => println!("F"),
            };
        }
    }

    return;
}

// 입력 가공 함수
fn get_splitted_line() -> Vec<String> {
    let mut line = String::new();
    io::stdin()
        .read_line(&mut line)
        .expect("Failed to read line");

    line.split_whitespace().map(str::to_string).collect()
}

// 소수점 세 자리에서 반올림
fn dump_three_decimal(num: f32) -> f32 {
    (num * 100.0).floor() / 100.0
}
