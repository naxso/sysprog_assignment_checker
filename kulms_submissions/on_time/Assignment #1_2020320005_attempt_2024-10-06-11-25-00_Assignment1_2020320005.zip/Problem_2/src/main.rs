struct Calculator {
    stack: [i32; 10000],
    top: usize
}

impl Calculator {
    fn cal() -> Calculator {
        Calculator {
            stack: [0; 10000],
            top: 0,
        }
    }

    fn num(&mut self, x: i32) {
        if self.top < 10000 {
            self.top += 1;
            self.stack[self.top as usize] = x;
        } else {
            println!("ERROR");
            std::process::exit(0);
        }
    }

    fn pop(&mut self) -> i32 {
        if self.top <= 0 {
            println!("ERROR");
            std::process::exit(0);
        }
        let x = self.stack[self.top as usize];
        self.top -= 1;
        x
    }

    fn inv(&mut self) {
        if self.top <= 0 {
            println!("ERROR");
            std::process::exit(0);
        }
        self.stack[self.top - 1] = -self.stack[self.top - 1];
    }

    fn dup(&mut self) {
        if self.top <= 0 {
            println!("ERROR");
            std::process::exit(0);
        }
        self.stack[self.top] = self.stack[(self.top - 1)];
        self.top += 1;
    }

    fn swp(&mut self) {
        if self.top < 2 {
            println!("ERROR");
            std::process::exit(0);
        }
        self.stack.swap(self.top - 1, self.top - 2);
    }

    fn add(&mut self) {
        if self.top < 2 {
            println!("ERROR");
            std::process::exit(0);
        }
        let first = self.stack[self.top - 1];
        let second = self.stack[self.top - 2];
        self.stack[self.top - 2] = first + second;
        self.top -= 1;
    }

    fn sub(&mut self) {
        if self.top < 2 {
            println!("ERROR");
            std::process::exit(0);
        }
        let first = self.stack[self.top - 1];
        let second = self.stack[self.top - 2];
        self.stack[self.top - 2] = second - first;
        self.top -= 1;
    }

    fn mul(&mut self) {
        if self.top < 2 {
            println!("ERROR");
            std::process::exit(0);
        }
        let first = self.stack[self.top - 1];
        let second = self.stack[self.top - 2];
        self.stack[self.top - 2] = first * second;
        self.top -= 1;
    }

    fn div(&mut self) {
        if self.top < 2 {
            println!("ERROR");
            std::process::exit(0);
        }
        let first = self.stack[self.top - 1];
        let second = self.stack[self.top - 2];
        if first == 0 {
            println!("ERROR");
            std::process::exit(0);
        }
        self.stack[self.top - 2] = second / first;
        self.top -= 1;
    }

    fn modulo(&mut self) {
        if self.top < 2 {
            println!("ERROR");
            std::process::exit(0);
        }
        let first = self.stack[self.top - 1];
        let second = self.stack[self.top - 2];
        if first == 0 {
            println!("ERROR");
            std::process::exit(0);
        }
        self.stack[self.top - 2] = second % first;
        self.top -= 1;
    }
} 
use std::io;

fn main() {
    let stdin = io::stdin();
    let mut lines = stdin.lines();

    loop {
        let mut program = [const { String::new() }; 100000];
        let mut i = 0;
        while let Some(Ok(line)) = lines.next() {
            if line.trim() == "END" {
                break;
            }
            if i == 100000 {
                println!("ERROR");
                std::process::exit(0);
            }
            program[i] = line.trim().to_string();
            i += 1;
        }
        
        let n: usize = match lines.next() {
            Some(Ok(line)) => line.trim().parse().unwrap(),
            _ => break,
        };

        let mut inputs = [0; 10000];
        for a in 0..n {
            if let Some(Ok(line)) = lines.next() {
                inputs[a] = line.trim().parse().unwrap();
            }
        }

        for a in 0..n {
            let mut calc = Calculator::cal();
            calc.num(inputs[a]);

            for b in 0..i {
                let mut command = program[b].split_whitespace();
                let cmd = command.next().unwrap();
                match cmd {
                    "NUM" => {
                        let x: i32 = command.next().unwrap().parse().unwrap();
                        calc.num(x);
                    }
                    "POP" => {
                        calc.pop();
                    }
                    "INV" => {
                        calc.inv();
                    }
                    "DUP" => {
                        calc.dup();
                    }
                    "SWP" => {
                        calc.swp();
                    }
                    "ADD" => {
                        calc.add();
                    }
                    "SUB" => {
                        calc.sub();
                    }
                    "MUL" => {
                        calc.mul();
                    }
                    "DIV" => {
                        calc.div();
                    }
                    "MOD" => {
                        calc.modulo();
                    }
                    _ => {
                        println!("ERROR");
                        std::process::exit(0);
                    }
                }
            }
            if calc.top != 1 {
                println!("ERROR");
            } else {
                println!("{}", calc.stack[calc.top - 1]);
            }
        }

        if let Some(Ok(line)) = lines.next() {
            if line.trim() == "QUIT" {
                break;
            }
        }
    }
}
