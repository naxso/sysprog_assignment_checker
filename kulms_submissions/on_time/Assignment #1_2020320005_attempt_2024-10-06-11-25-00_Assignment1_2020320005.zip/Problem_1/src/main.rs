use std::io;

fn main() {
    let mut input = String::new();
    
    io::stdin().read_line(&mut input).unwrap();
    let mut input = input.split_whitespace();

    let N: i64 = input.next().unwrap().parse().unwrap();
    let X: f64 = input.next().unwrap().parse().unwrap();
    
    let mut sum: f64 = 0.0;
    let mut total_credits: f64 = 0.0;
    
    for a in 1..N {
        let mut score = String::new();
        
        io::stdin().read_line(&mut score).unwrap();
        
        let mut score = score.split_whitespace();
        
        let c: f64 = score.next().unwrap().parse().unwrap();
        let g = score.next().unwrap();
        
        let grade = match g {
            "A+" => 4.5,
            "A0" => 4.0,
            "B+" => 3.5,
            "B0" => 3.0,
            "C+" => 2.5,
            "C0" => 2.0,
            "D+" => 1.5,
            "D0" => 1.0,
            _ => 0.0,
        };
        
        sum += c * grade;
        total_credits += c;
    }
    
    let mut fin = String::new();
    io::stdin().read_line(&mut fin).unwrap();
    let fin: f64 = fin.trim().parse().unwrap();
    total_credits += fin;
    
    if sum / total_credits > X {
        println!("F");
    } else if (sum + fin * 1.0) / total_credits > X {
        println!("D0");
    } else if (sum + fin * 1.5) / total_credits > X {
        println!("D+");
    } else if (sum + fin * 2.0) / total_credits > X {
        println!("C0");
    } else if (sum + fin * 2.5) / total_credits > X {
        println!("C+");
    } else if (sum + fin * 3.0) / total_credits > X {
        println!("B0");
    } else if (sum + fin * 3.5) / total_credits > X {
        println!("B+");
    } else if (sum + fin * 4.0) / total_credits > X {
        println!("A0");
    } else if (sum + fin * 4.5) / total_credits > X {
        println!("A+");
    } else {
        println!("impossible");
    }
    
}
