use std::io;

fn main() {
    let mut program_arr: [i64; 100000] = [0; 100000];
    let mut k = 0;
    let mut result: [i64; 10000] = [0; 10000];
    let mut stack: [i64; 1000] = [0; 1000];
    let mut numarray: [i64; 10000] = [0; 10000];
    let mut numarrayindex = 0;
    let mut program_arr_count = 0;

    loop {
        for i in 0..100000 {
            let mut program_arr_input = String::new();
            io::stdin().read_line(&mut program_arr_input).expect("program_arr Input Error!");
            if program_arr_input.trim() == "QUIT" {
                for i in 0..k {
                    if result[i] > 1000000000 || result[i] < -1000000000{
                        if result[i] == -10000000000{
                            println!("");
                        }
                        else 
                        {println!("ERROR");
                        }
                    }
                    else {
                        println!("{}", result[i]);
                    }
            }
            return;

        }
            let program_arr_input = program_arr_input.trim();
            program_arr[i] = match program_arr_input {
                "POP" => 2,
                "INV" => 3,
                "DUP" => 4,
                "SWP" => 5,
                "ADD" => 6,
                "SUB" => 7,
                "MUL" => 8,
                "DIV" => 9,
                "MOD" => 10,
                "END" => 11,
                _ => 1,
            };

            if program_arr_input.trim().len() > 4 {
                let program_arr_input: i64 = program_arr_input[4..].trim().parse().expect("num casting error");
                numarray[numarrayindex] = program_arr_input;
                numarrayindex += 1;
            }

            program_arr_count += 1;

            if program_arr[i] == 11 {
                break;
            }
        }
        //END 입력
        numarrayindex = 0;
        let mut count = String::new();
        io::stdin().read_line(&mut count).expect("Count Input Error!");
        let count: usize = count.trim().parse().expect("Count Casting Error!");

        for _j in 0..count + 1 {
            let mut input_int = String::new();
            io::stdin().read_line(&mut input_int).expect("input string error!");

            if input_int.trim() == "" {
                result[k] = -10000000000;
                k += 1;
                break;
            }

            let input_int: i64 = input_int.trim().parse().expect("input Error!");
            stack[0] = input_int;
            let mut stacklen = 1;

            for l in 0..program_arr_count {
                if program_arr[l] == 1 {//num x
                    if stacklen == 1000 {
                        result[k] = 10000000000;
                        numarrayindex = 0;
                        k += 1;
                        break;
                    } else {
                        stack[stacklen] = numarray[numarrayindex];
                        numarrayindex += 1;
                        stacklen += 1;
                    }
                } else if program_arr[l] == 2 {//pop
                    if stacklen == 0 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    stacklen -= 1;
                } else if program_arr[l] == 3 {//inv
                    if stacklen == 0 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    stack[stacklen - 1] = -stack[stacklen - 1] * 2;
                } else if program_arr[l] == 4 {//dup
                    if stacklen == 1000 || stacklen == 0 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    } else {
                        stack[stacklen] = stack[stacklen-1];
                        stacklen += 1;
                    }
                } else if program_arr[l] == 5 {//swp
                    if stacklen < 2 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    let temp = stack[stacklen-1];
                    stack[stacklen-2] = stack[stacklen-1];
                    stack[stacklen-1] = temp;
                } else if program_arr[l] == 6 {//add
                    if stacklen < 2 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    } else {
                        stack[stacklen-2] += stack[stacklen-1];
                        stacklen -= 1;
                    }
                } else if program_arr[l] == 7 {//sub
                    if stacklen < 2 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    stack[stacklen-2] = stack[stacklen-1] - stack[stacklen-2];
                    stacklen -= 1;
                } else if program_arr[l] == 8 {//mul
                    if stacklen < 2 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    stack[stacklen-2] *= stack[stacklen-1];
                    stacklen -= 1;
                } else if program_arr[l] == 9 {//div
                    if stacklen < 2 || stack[stacklen-1] == 0 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    stack[stacklen-2] = stack[stacklen-2] / stack[stacklen-1];
                    stacklen -= 1;
                } else if program_arr[l] == 10 {//mod
                    if stacklen < 2 || stack[stacklen-1] == 0 {
                        result[k] = 10000000000;
                        k += 1;
                        break;
                    }
                    stack[stacklen-2] = stack[stacklen-2] % stack[stacklen-1];
                    stacklen -= 1;
                } else if program_arr[l] == 11 {//end
                    if stacklen != 1 {
                        result[k] = 10000000000;
                        k += 1;
                        numarrayindex = 0;
                        break;
                    } else {
                        result[k] = stack[0];
                        numarrayindex = 0;
                        k += 1;
                        break;
                    }
                }
            }
        }
    }
}
