use std::io;
fn main(){
    let mut arr:[[i32;19];19]=[[0;19];19];
    for i in 0..19{    
        let mut line=String::new();
        let mut j:usize=0;
        io::stdin()
            .read_line(&mut line)
            .expect("read line error!");//문자열 입력 읽기(한줄)
    while j<38{
        let a=&line[j..j+1];
        let b:i32=a.trim().parse().expect("parsing error!");
        arr[i][j/2]=b;
        j+=2;
    }
    }
    //2차원 배열에 대입
    //세로로
    for i in 0..19{
        for j in 0..19{
            if arr[i][j]==1||arr[i][j]==2{
                if (arr[i+1][j]==arr[i][j])
                &&(arr[i+2][j]==arr[i+1][j])
                &&(arr[i+3][j]==arr[i+2][j])
                &&(arr[i+4][j]==arr[i+3][j]){
                    println!("{}",arr[i][j]);
                    print!("{} {}",i+1,j+1);
                    return;
                }
            }
        }
    }
    //가로로
    for i in 0..19{
        for j in 0..19{
            if arr[i][j]==1||arr[i][j]==2{
                if (arr[i][j+1]==arr[i][j])
                &(arr[i][j+2]==arr[i][j+1])
                &&(arr[i][j+3]==arr[i][j+2])
                &&(arr[i][j+4]==arr[i][j+3]){
                    println!("{}",arr[i][j]);
                    print!("{} {}",i+1,j+1);
                    return;
                }
                }
            }
        }
    //대각으로(좌상단-우하단)
    for i in 0..19{
        for j in 0..19{
            if arr[i][j]==1||arr[i][j]==2{
                if (arr[i+1][j+1]==arr[i][j])
                &&(arr[i+2][j+2]==arr[i+1][j+1])
                &&(arr[i+3][j+3]==arr[i+2][j+2])
                &&(arr[i+4][j+4]==arr[i+3][j+3]){
                    println!("{}",arr[i][j]);
                    print!("{} {}",i+1,j+1);
                    return;
                }
            }
        }
    }
    //대각으로(우상단-좌하단)
    for i in 0..19{
        for j in 0..19{
            if arr[i][j]==1||arr[i][j]==2{
                if (arr[i-1][j-1]==arr[i][j])
                &&(arr[i-2][j-2]==arr[i-1][j-1])
                &&(arr[i-3][j-3]==arr[i-2][j-2])
                &&(arr[i-4][j-4]==arr[i-3][j-3]){
                    println!("{}",arr[i][j]);
                    print!("{} {}",i+1,j+1);
                    return;
                }
                }
            }
        }
}