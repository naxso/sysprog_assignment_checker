use std::io;

struct Stack {
    data: Vec<i64>,
}

impl Stack {
    fn new() -> Self {
        Stack { data: Vec::new() }
    }

    fn push(&mut self, value: i64) {
        self.data.push(value);
    }

    fn pop(&mut self) -> Option<i64> {
        self.data.pop()
    }

    fn top(&self) -> Option<&i64> {
        self.data.last()
    }

    fn size(&self) -> usize {
        self.data.len()
    }
}

fn main() {
    let mut results = Vec::new();
    let limit = 1_000_000_000;
    let mut commands = Vec::new();
    let mut input = String::new();
    
    loop {
        match io::stdin().read_line(&mut input) {
            Ok(_) => {
                let line = input.trim();

                if line == "QUIT" {
                    break;
                }

                if line.is_empty() {
                    if !commands.is_empty() {
                        process_command_set(&commands, &mut results, limit);
                        commands.clear();
                        results.push(String::new());
                    }
                } else {
                    commands.push(line.to_string());
                }
            },
            Err(e) => {
                eprintln!("Failed to read input: {}", e);
                return;
            }
        }
        input.clear();
    }

    for result in results {
        println!("{}", result);
    }
}

fn process_command_set(commands: &Vec<String>, results: &mut Vec<String>, limit: i64) {
    let mut iter = commands.iter();

    while let Some(command) = iter.next() {
        let parts: Vec<&str> = command.split_whitespace().collect();
        match parts[0] {
            "END" => {
                if let Some(num_exec_command) = iter.next() {
                    let num_exec: i32 = match num_exec_command.trim().parse() {
                        Ok(n) => n,
                        Err(_) => {
                            results.push("ERROR".to_string());
                            return;
                        }
                    };

                    for _ in 0..num_exec {
                        let mut stack = Stack::new();
                        let mut error_flag = false;

                        if let Some(initial_value_command) = iter.next() {
                            let init_value: i64 = match initial_value_command.trim().parse() {
                                Ok(v) => v,
                                Err(_) => {
                                    results.push("ERROR".to_string());
                                    continue;
                                }
                            };
                            stack.push(init_value);
                        }

                        for command in commands.iter() {
                            if error_flag {
                                break;
                            }

                            let parts: Vec<&str> = command.split_whitespace().collect();
                            match parts[0] {
                                "NUM" => {
                                    if parts.len() != 2 {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }
                                    let num: i64 = match parts[1].parse() {
                                        Ok(n) => n,
                                        Err(_) => {
                                            results.push("ERROR".to_string());
                                            error_flag = true;
                                            break;
                                        }
                                    };
                                    stack.push(num);
                                },
                                "POP" => {
                                    if stack.pop().is_none() {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }
                                },
                                "INV" => {
                                    if let Some(&top) = stack.top() {
                                        stack.pop();
                                        stack.push(-top);
                                    } else {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }
                                },
                                "DUP" => {
                                    if let Some(&top) = stack.top() {
                                        stack.push(top);
                                    } else {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }
                                },
                                "SWP" => {
                                    if stack.size() < 2 {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }
                                    let a = match stack.pop() {
                                        Some(val) => val,
                                        None => {
                                            results.push("ERROR".to_string());
                                            error_flag = true;
                                            break;
                                        }
                                    };
                                    let b = match stack.pop() {
                                        Some(val) => val,
                                        None => {
                                            results.push("ERROR".to_string());
                                            error_flag = true;
                                            break;
                                        }
                                    };
                                    stack.push(a);
                                    stack.push(b);
                                },
                                "ADD" | "SUB" | "MUL" | "DIV" | "MOD" => {
                                    if stack.size() < 2 {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }
                                    let b = match stack.pop() {
                                        Some(val) => val,
                                        None => {
                                            results.push("ERROR".to_string());
                                            error_flag = true;
                                            break;
                                        }
                                    };
                                    let a = match stack.pop() {
                                        Some(val) => val,
                                        None => {
                                            results.push("ERROR".to_string());
                                            error_flag = true;
                                            break;
                                        }
                                    };
                                    let result = match parts[0] {
                                        "ADD" => a + b,
                                        "SUB" => a - b,
                                        "MUL" => a * b,
                                        "DIV" => {
                                            if b == 0 {
                                                results.push("ERROR".to_string());
                                                error_flag = true;
                                                break;
                                            }
                                            a / b
                                        },
                                        "MOD" => {
                                            if b == 0 {
                                                results.push("ERROR".to_string());
                                                error_flag = true;
                                                break;
                                            }
                                            a % b
                                        },
                                        _ => {
                                            results.push("ERROR".to_string());
                                            error_flag = true;
                                            break;
                                        }
                                    };
                                    
                                    if result.abs() > limit {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                        break;
                                    }

                                    stack.push(result);
                                },
                                _ => {
                                    if parts[0] != "END" {
                                        results.push("ERROR".to_string());
                                        error_flag = true;
                                    }
                                    break;
                                }
                            }
                        }

                        if !error_flag {
                            if stack.size() != 1 {
                                results.push("ERROR".to_string());
                            } else {
                                if let Some(result) = stack.top() {
                                    results.push(result.to_string());
                                } else {
                                    results.push("ERROR".to_string());
                                }
                            }
                        }
                    }

                    break;
                }
            },
            _ => continue,
        }
    }
}
