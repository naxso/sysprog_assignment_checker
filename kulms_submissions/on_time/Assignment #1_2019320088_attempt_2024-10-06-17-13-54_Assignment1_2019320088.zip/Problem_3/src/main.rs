use std::io;

fn main() {
    let mut board = [[0; 19]; 19];

    // 보드 입력 받기
    for i in 0..19 {
        let mut input = String::new();
        match io::stdin().read_line(&mut input) {
            Ok(_) => {
                let row: Vec<i32> = input.trim().split_whitespace()
                    .filter_map(|x| x.parse().ok()).collect();
                if row.len() != 19 {
                    eprintln!("Invalid input: Expected 19 values per line.");
                    return;
                }
                for j in 0..19 {
                    board[i][j] = row[j];
                }
            }
            Err(e) => {
                eprintln!("Failed to read input: {}", e);
                return;
            }
        }
    }

    let directions = [(0, 1), (1, 0), (1, 1), (1, -1)];
    
    for i in 0..19 {
        for j in 0..19 {
            if board[i][j] == 0 {
                continue;
            }

            let current = board[i][j];
            for &(di, dj) in &directions {
                let mut count = 1;

                let mut ni = i as i64;
                let mut nj = j as i64;
                for _ in 0..4 {
                    ni += di;
                    nj += dj;

                    if ni < 0 || nj < 0 || ni >= 19 || nj >= 19 {
                        break;
                    }

                    if board[ni as u64][nj as u64] == current {
                        count += 1;
                    } else {
                        break;
                    }
                }

                if count == 5 {
                    let prev_i = i as i64 - di;
                    let prev_j = j as i64 - dj;
                    let next_i = ni + di;
                    let next_j = nj + dj;

                    // Consecutive 6 check
                    let prev_valid = prev_i >= 0 && prev_j >= 0 && prev_i < 19 && prev_j < 19 && board[prev_i as u64][prev_j as u64] == current;
                    let next_valid = next_i >= 0 && next_j >= 0 && next_i < 19 && next_j < 19 && board[next_i as u64][next_j as u64] == current;

                    if !prev_valid && !next_valid {
                        println!("{}", current);
                        println!("{} {}", i + 1, j + 1);
                        return;
                    }
                }
            }
        }
    }

    println!("0");
}
