use std::io;

fn main() {
    let mut line = String::new();
    
    let n: i32;
    let goal: i32;
    
    match io::stdin().read_line(&mut line) {
        Ok(_) => {

            let values: Vec<&str> = line.trim().split_whitespace().collect();
            
            if values.len() != 2 {
                eprintln!("Invalid input: Expected two values.");
                return;
            }
            
            n = match values[0].parse() {
                Ok(num) => num,
                Err(_) => {
                    eprintln!("Invalid input: First value should be an integer.");
                    return;
                }
            };
            
            goal = match values[1].parse::<f64>() {
                Ok(num) => (num * 100.0) as i32,
                Err(_) => {
                    eprintln!("Invalid input: Second value should be a floating-point number.");
                    return;
                }
            };
            
        },
        Err(e) => {
            eprintln!("Failed to read input: {}", e);
            return;
        }
    }

    line.clear();
    
    let mut total_credits = 0;
    let mut total_points = 0;

    let grade_table = [
        ("A+", 450), ("A0", 400), ("B+", 350), ("B0", 300),
        ("C+", 250), ("C0", 200), ("D+", 150), ("D0", 100), ("F", 0),
    ];

    for _ in 0..(n-1) {
        match io::stdin().read_line(&mut line) {
            Ok(_) => {
                let parts: Vec<&str> = line.trim().split_whitespace().collect();
                
                if parts.len() != 2 {
                    eprintln!("Invalid input: Expected credit and grade.");
                    return;
                }

                let credit: i32 = match parts[0].parse() {
                    Ok(num) => num,
                    Err(_) => {
                        eprintln!("Invalid input: Credit should be an integer.");
                        return;
                    }
                };

                let grade = parts[1];
                let grade_point = match grade_table.iter().find(|&&(g, _)| g == grade) {
                    Some(&(_, gp)) => gp,
                    None => {
                        eprintln!("Invalid input: Grade {} is not recognized.", grade);
                        return;
                    }
                };

                total_credits += credit;
                total_points += credit * grade_point;
            },
            Err(e) => {
                eprintln!("Failed to read input: {}", e);
                return;
            }
        }
        line.clear();
    }

    line.clear();
    let last_credit: i32;

    match io::stdin().read_line(&mut line) {
        Ok(_) => {
            last_credit = match line.trim().parse() {
                Ok(num) => num,
                Err(_) => {
                    eprintln!("Invalid input: Last credit should be an integer.");
                    return;
                }
            };
        },
        Err(e) => {
            eprintln!("Failed to read input: {}", e);
            return;
        }
    }

    let required_point = goal * (total_credits + last_credit) - total_points;
    let required_grade = required_point / last_credit + 1;

    let result = if required_grade < -5 {
        "F"
    } else if required_grade < 95 {
        "D0"
    } else if required_grade < 145 {
        "D+"
    } else if required_grade < 195 {
        "C0"
    } else if required_grade < 245 {
        "C+"
    } else if required_grade < 295 {
        "B0"
    } else if required_grade < 345 {
        "B+"
    } else if required_grade < 395 {
        "A0"
    } else if required_grade < 445 {
        "A+"
    } else {
        "impossible"
    };

    println!("{}", result);
}
