// Gomoku
// Three states: 0 for tie, 1 for black, 2 for white
// only one player can win

use std::io::{self, BufRead};
const N: usize = 19;

fn main() {
    // Input loop
    let stdin = io::stdin();
    let mut lines = stdin.lock().lines();
    let mut board: [[u8; N]; N] = [[0; N]; N];
    
    // finishing input
    for i in 0..N {
        let line = lines.next().unwrap().unwrap();
        let mut j = 0;
        for c in line.split_whitespace() {
            let value = c.trim().parse::<u8>().unwrap();
            board[i][j] = value;
            j += 1;
        }
    }

    // Check if there are 5 consecutive stones
    for i in 0..N {
        for j in 0..N {
            if board[i][j] != 0 {
                if check_consecutive(&board, (i, j), (0, 0), 1) == 5 {
                    println!("{}", board[i][j]);
                    println!("{} {}", i + 1, j + 1);
                    return;
                }
            }
        }
    }
    println!("0");
}

// recursive function to check if there are 5 consecutive stones
// only check the 4 directions: right, down, right-down, right-up
// base-case is when the current position is out of the board or the stone is different
// comparing the current stone with the previous one
fn check_consecutive(board: &[[u8; 19]; 19], pos: (usize, usize), direction: (i8, i8), mut depth: u8) -> u8 {
    // base-case and invalid cases
    let out_of_board: bool = pos.0 >= N || pos.1 >= N; // not necessary to check for negative values
    let no_stone: bool = board[pos.0][pos.1] == 0;
    if out_of_board || no_stone {return depth - 1;}

    if direction != (0, 0) { // not the first call
        if pos.0 as isize - direction.0 as isize >= 0 && pos.1 as isize - direction.1 as isize >= 0 { // if previous stone is on the board
            let different_stone: bool = board[pos.0][pos.1] != board[pos.0 - direction.0 as usize][pos.1 - direction.1 as usize];
            if different_stone { 
                return depth - 1;
            }
        }
    }

    if direction == (0, 0) { // first call, implies depth is 1
        let mut depth_list: [u8; 4] = [1; 4];
        depth_list[0] = check_consecutive(board, (pos.0 +1, pos.1), (1, 0), depth + 1); // right
        depth_list[1] = check_consecutive(board, (pos.0, pos.1 + 1), (0, 1), depth + 1); // down
        depth_list[2] = check_consecutive(board, (pos.0 +1, pos.1 + 1), (1, 1), depth + 1); // right-down
        depth_list[3] = check_consecutive(board, (pos.0 -1, pos.1 + 1), (-1, 1), depth + 1); // right-up
        for i in 0..4 {
            if depth_list[i] == 5 {
                return 5;
            }
        }
        return 0;
    } else {
        depth = check_consecutive(board, (pos.0 + direction.0 as usize, pos.1 + direction.1 as usize), direction, depth + 1);
        return depth;
    }
}
    
