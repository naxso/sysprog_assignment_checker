use std::io::{self, BufRead};
use std::collections::VecDeque;

fn main() {
    // Input loop
    let stdin = io::stdin();
    let mut lines = stdin.lock().lines();
    let mut deque = VecDeque::new();

    // finishing input
    while let Some(Ok(line)) = lines.next() {
        let processed_line = line.trim().to_string();
        deque.push_back(processed_line.clone());
        if processed_line == "QUIT" {
            break;
        }
    }
    
    // per calculator loop
    loop { 
        if deque.is_empty() {break;}

        let mut line = deque.pop_front().unwrap();
        if line == "QUIT" {break;}
        if line == "" {continue;}
        
        let mut instructions = Vec::new();
        let mut stack = Vec::<i32>::new();

        // Saving instructions while line != END
        loop {
            if line == "END" {break;}
            instructions.push(line.clone());
            line = deque.pop_front().unwrap();
        }
    
    
        // Read one number at a time for i in range n
        let n: i32 = deque.pop_front().unwrap().parse::<i32>().unwrap();
        for _i in 0..n {
            let number = deque.pop_front().unwrap().parse::<i32>().unwrap();
            stack.push(number);
            // Execute instructions
            for instruction in &instructions {
                if stack.len() == 0 {
                    break;
                }
                match instruction.as_str() {
                    "ADD" => add(&mut stack),
                    "SUB" => sub(&mut stack),
                    "INV" => inv(&mut stack),
                    "DUP" => dup(&mut stack),
                    "POP" => pop(&mut stack),
                    "SWP" => swp(&mut stack),
                    "MUL" => mul(&mut stack),
                    "DIV" => div(&mut stack),
                    "MOD" => modulo(&mut stack),
                    _ => { // NUM
                        let parts: Vec<&str> = instruction.split_whitespace().collect();
                        if parts.len() == 2 {
                            let n = parts[1].parse::<i32>().unwrap();
                            num(&mut stack, n);
                        } else {
                            println!("ERROR");
                        }
                    }
                }
            }
            if stack.len() != 1 {
                println!("ERROR");
            } else if stack[0] < -1_000_000_000 || stack[0] > 1_000_000_000 {
                println!("ERROR");
            } else {
                println!("{}", stack[0]);
            }
            stack.clear();
        }
        println!();
        deque.pop_front();
    }


}

fn add (stack: &mut Vec<i32>) {
    let num1 = stack.pop().unwrap();
    let num2 = stack.pop().unwrap();
    stack.push(num1 + num2);
}

fn sub (stack: &mut Vec<i32>) {
    let num1 = stack.pop().unwrap();
    let num2 = stack.pop().unwrap();
    stack.push(num1 - num2);
}

fn inv (stack: &mut Vec<i32>) {
    let num = stack.pop().unwrap();
    stack.push(-num);
}

fn dup (stack: &mut Vec<i32>) {
    let num = stack.pop().unwrap();
    stack.push(num);
    stack.push(num);
}

// Maybe redundant
fn pop (stack: &mut Vec<i32>) {
    stack.pop();
}

fn num (stack: &mut Vec<i32>, n: i32) {
    stack.push(n);
}

fn swp (stack: &mut Vec<i32>) {
    let num1: i32 = stack.pop().expect("None");
    let num2: i32 = stack.pop().expect("None");
    stack.push(num1);
    stack.push(num2);
}

fn mul (stack: &mut Vec<i32>) {
    let num1 = stack.pop().unwrap();
    let num2 = stack.pop().unwrap();
    stack.push(num1 * num2);
}

fn div (stack: &mut Vec<i32>) {
    let num2 = stack.pop().unwrap();
    let num1 = stack.pop().unwrap();
    stack.push(num1 / num2);
}

fn modulo (stack: &mut Vec<i32>) {
    let num2 = stack.pop().unwrap();
    let num1 = stack.pop().unwrap();
    stack.push(num1 % num2);
}