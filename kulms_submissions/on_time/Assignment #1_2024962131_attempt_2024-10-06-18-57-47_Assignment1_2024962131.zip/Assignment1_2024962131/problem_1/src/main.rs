// Minimum grade

use std::io::{self, BufRead};

fn main() {

    let grade_conversion = [
        ("A+", 4.5),
        ("A0", 4.0),
        ("B+", 3.5),
        ("B0", 3.0),
        ("C+", 2.5),
        ("C0", 2.0),
        ("D+", 1.5),
        ("D0", 1.0),
        ("F", 0.0),
    ];

    let stdin = io::stdin();
    let mut lines = stdin.lock().lines();

    // first line
    let first_line = lines.next().unwrap().unwrap();
    let parts: Vec<&str> = first_line.split_whitespace().collect();
    let n: usize = parts[0].parse().unwrap();
    let target_gpa: f64 = parts[1].parse().unwrap();

    // rest of the lines
    let mut total_credits = 0;
    let mut total_points = 0.0;

    for _l in 0..(n-1) {
        let line = lines.next().unwrap().unwrap();
        let parts: Vec<&str> = line.split_whitespace().collect();
        let credits: i32 = parts[0].parse().unwrap();
        let grade = parts[1];
        total_credits += credits;
        total_points += credits as f64 * find_value_by_grade(grade, &grade_conversion);
    }
    
    let last_line = lines.next().unwrap().unwrap();
    let last_credits: i32 = last_line.parse().unwrap(); // credits of the last subject
    total_credits += last_credits;
    
    let remaining_gpa = target_gpa as f64 - total_points / total_credits as f64;
    let remaining_gpa = (remaining_gpa * 100.0).floor() / 100.0; // rounding to 2 decimal place

    // Shortcuts for edge cases
    if remaining_gpa < 0.0 {
        println!("F"); // Only needs passing grade
        return;
    } else if remaining_gpa >= last_credits as f64 * 4.5 {
        println!("A+");
        return;
    }
    
    // Main loop
    for (g, v) in grade_conversion.iter().rev() { 
        let mut temp_gpa = (total_points + last_credits as f64 * v) / total_credits as f64;
        temp_gpa = (temp_gpa * 100.0).floor() / 100.0; // rounding to 2 decimal places

        if temp_gpa > target_gpa {
            println!("{}", g);
            return;
        }
    }
    println!("impossible");
    return;
}

// LOOKUP FUNCTIONS
// Converts letter grade to GPA value
fn find_value_by_grade<'a>(grade: &'a str, grade_conversion: &'a [(&'a str, f64)]) -> f64 {
    for (g, v) in grade_conversion {
        if *g == grade {
            return *v;
        }
    }
    0.0
}