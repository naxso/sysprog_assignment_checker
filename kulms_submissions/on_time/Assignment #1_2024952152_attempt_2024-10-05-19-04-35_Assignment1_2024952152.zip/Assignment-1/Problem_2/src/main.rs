// #####################################################################
// Imports
// #####################################################################
use std::io::{self, BufRead};


// #####################################################################
// Stack Calculator Structure
// #####################################################################
#[derive(Debug)]
struct StackCalculator {
    stack: Vec<i64>,
    program: Vec<String>,
    numbers: Vec<i64>,
}

impl std::fmt::Display for StackCalculator {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        if self.stack.len() != 1 {
            write!(f, "ERROR")
        }
        else {
            let element = self.stack[0];
            write!(f, "{element}")
        }
    }
}


// #####################################################################
// Main Function of Program
// #####################################################################
fn main() {
    println!("Start of program.");

    // Take in all input lines until END into buffer
    let mut inputs = Vec::new();

    // Use stdin to read input lines
    let stdin = io::stdin();
    let handle = stdin.lock();

    for line in handle.lines() {
        let line = line.expect("Problem reading line.");

        if line.trim() == "QUIT" {
            break;
        }

        inputs.push(line.clone());
    }

    println!();


    // Keep track of all calculators from input
    let mut calculators_list: Vec<StackCalculator> = Vec::new();
    let mut skip: bool = false;

    let mut new_calculator: StackCalculator = StackCalculator {
        stack:  Vec::new(),
        program:  Vec::new(),
        numbers:  Vec::new(),
    };

    let mut program: bool = true;

    // Process all of input
    for input in &inputs {
        if skip {
            skip = false;
            continue;
        }

        // If QUIT finish processing input
        if input.trim() == "QUIT" {
            break;
        }

        // If new line current calculator complete
        if input.trim() == "" {
            calculators_list.push(new_calculator);
            
            new_calculator = StackCalculator {
                stack:  Vec::new(),
                program:  Vec::new(),
                numbers:  Vec::new(),
            };

            program = true;

            continue;
        }

        // What part of calculator input currently at
        if input.trim() == "END" {
            program = false;
            skip = true;
            continue;
        }

        // Add input to program part of calculator
        if program {
            new_calculator.program.push(input.clone());
        }
        // Add input to numbers part of calculator
        else {
            let num: i64 = input.trim().parse().unwrap();
            new_calculator.numbers.push(num);
        }
    }

    // Calculate each calculator
    for mut calculator in calculators_list {
        // println!("Current calculator: {:?}", calculator);
        for num in &calculator.numbers {
            // println!("Initial Number: {}", num);
            calculator.stack.push(*num);
            let mut error: bool = false;
            // println!("Initial Stack: {calculator}");

            for line in &calculator.program {
                match process_command(&mut calculator.stack, &line[..]) {
                    Ok(()) => {}
                    Err(_) => {
                        println!("ERROR");
                        error  = true;
                        break;
                    }
                }
            }

            if !error {
                println!("{calculator}");
            }

            calculator.stack.clear();
        }
        println!();
    }
}


// #####################################################################
// Functions of the Stack Calculator
// #####################################################################

// Functionalities
fn num(stack: &mut Vec<i64>, x: i64) -> Result<(), &'static str> {
    stack.push(x);
    Ok(())
}

fn pop(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.is_empty() {
        return Err("ERROR: Stack underflow.");
    }

    stack.pop();
    Ok(())
}

fn inv(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.is_empty() {
        return Err("ERROR: Stack underflow.");
    }

    let val = stack.pop().unwrap();
    let new_val = -val;
    stack.push(new_val);
    Ok(())
}

fn dup(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.is_empty() {
        return Err("ERROR: Stack underflow.");
    }

    let val = stack.pop().unwrap();
    stack.push(val);
    stack.push(val);
    Ok(())
}

fn swp(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.len() < 2 {
        return Err("ERROR: Stack contains less than 2 elements.");
    }

    let val1 = stack.pop().unwrap();
    let val2 = stack.pop().unwrap();
    stack.push(val2);
    stack.push(val1);
    Ok(())
}

fn add(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.len() < 2 {
        return Err("ERROR: Stack contains less than 2 elements.");
    }

    let val1 = stack.pop().unwrap();
    let val2 = stack.pop().unwrap();
    let sum = val1 + val2;

    if sum.abs() > 1_000_000_000 {
        return Err("ERROR: Sum exceeds the limit");
    }

    stack.push(sum);
    Ok(())
}

fn sub(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.len() < 2 {
        return Err("ERROR: Stack contains less than 2 elements.");
    }

    let val1 = stack.pop().unwrap();
    let val2 = stack.pop().unwrap();
    let diff = val2 - val1;

    if diff.abs() > 1_000_000_000 {
        return Err("ERROR: Difference exceeds the limit");
    }

    stack.push(diff);
    Ok(())
}

fn mul(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.len() < 2 {
        return Err("ERROR: Stack contains less than 2 elements.");
    }

    let val1 = stack.pop().unwrap();
    let val2 = stack.pop().unwrap();
    let product = val1 * val2;

    if product.abs() > 1_000_000_000 {
        return Err("ERROR: Product exceeds the limit");
    }

    stack.push(product);
    Ok(())
}

fn div(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.len() < 2 {
        return Err("ERROR: Stack contains less than 2 elements.");
    }

    let val1 = stack.pop().unwrap();
    let val2 = stack.pop().unwrap();
    
    if val1 == 0 {
        return Err("ERROR: Division by 0.");
    }

    let quotient = val2 / val1;
    stack.push(quotient);
    Ok(())
}

fn modu(stack: &mut Vec<i64>) -> Result<(), &'static str> {
    if stack.len() < 2 {
        return Err("ERROR: Stack contains less than 2 elements.");
    }

    let val1 = stack.pop().unwrap();
    let val2 = stack.pop().unwrap();
    
    if val1 == 0 {
        return Err("ERROR: Modulor by 0.");
    }

    let remainder = val2 % val1;
    let remainder = if val2 >= 0 {remainder} else {-remainder};
    stack.push(remainder);
    Ok(())
}

// Processing
fn process_command(stack: &mut Vec<i64>, command: &str) -> Result<(), &'static str> {
    let args: Vec<&str> = command.split_whitespace().collect();
    let op = args[0];
    let number = if args.len() == 2 {args[1].parse().unwrap()} else {0};
    match op {
        "NUM" => return num(stack, number),
        "POP" => return pop(stack),
        "INV" => return inv(stack),
        "DUP" => return dup(stack),
        "SWP" => return swp(stack),
        "ADD" => return add(stack),
        "SUB" => return sub(stack),
        "MUL" => return mul(stack),
        "DIV" => return div(stack),
        "MOD" => return modu(stack),
        _ => return Err("Unknown command."),
    }
} 