// #####################################################################
// Imports
// #####################################################################
use std::io::{self, BufRead};


// #####################################################################
// Go Board Structure
// #####################################################################
#[derive(Debug)]
struct GoBoard {
    board: [[i64; 19]; 19],
}

impl std::fmt::Display for GoBoard {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        for row in &self.board {
            for &cell in row {
                write!(f, "{:1} ", cell)?;  // Format each cell with 2 spaces padding
            }
            writeln!(f)?;  // Move to the next line after each row
        }
        Ok(())
    }
}


// #####################################################################
// Main Function of Program
// #####################################################################
fn main() {
    println!("Start of program.");

    // Take in all input lines until END into buffer
    let mut inputs: Vec<String> = Vec::new();

    // Use stdin to read input lines
    let stdin = io::stdin();
    let handle = stdin.lock();
    let mut count = 0;

    for line in handle.lines() {
        if count >= 18 {
            break;
        }

        let line = line.expect("Problem reading line.");

        inputs.push(line.clone());
        count += 1;
    }

    println!();


    // Add all inputs into 2D array representing go board
    let mut go_board: GoBoard = GoBoard {
        board: [[0; 19]; 19],
    };

    let mut i: usize = 0;

    for line in &inputs {
        let cur_line: Vec<usize> = line
                            .split_whitespace()
                            .map(|s| s.parse().unwrap())
                            .collect();
        for (j, num) in cur_line.iter().enumerate() {
            go_board.board[i][j] = *num as i64;
        }
        i += 1;
    }

    // println!("Board: \n{go_board}");

    // Check for winners
    let (winner, row, col) = check_winner(&go_board.board);

    println!("{}", winner);

    if winner != 0 {
        println!("{} {}", row, col);
    }
}


// #####################################################################
// Main Function of Program
// #####################################################################
fn check_winner(board: &[[i64; 19]; 19]) -> (i64, usize, usize) {
    let directions: [(i64, i64); 4] = [(0, 1), (1, 0), (1, 1), (1, -1)];
    let length = 19;

    for i in 0..length {
        for j in 0..length {
            if board[i][j] != 0 {
                let player = board[i][j];
                for &(dx, dy) in directions.iter() {
                    if five_consecutive(board, i as i64, j as i64, dx, dy, player) {
                        return (player, i + 1, j + 1);
                    }
                }
            }
        }
    }

    // No winner found
    (0, 0, 0)
}

fn five_consecutive(board: &[[i64; 19]; 19], x: i64, y: i64, dx: i64, dy: i64, player: i64) -> bool {
    let length = 19;
    let mut count = 1;

    // Check 5 in a row
    for i in 1..5 {
        let new_x = x + i * dx;
        let new_y = y + i * dy;

        if new_x >= 0 && new_x < length && new_y >= 0 && new_y < length && board[new_x as usize][new_y as usize] == player {
            count += 1;
        } else {
            break;
        }
    }

    // Check exactly 5 in a row
    if count == 5 {
        let before = x - dx >= 0 && x - dx < length && y - dy >= 0 && y - dy < length && board[(x - dx) as usize][(y - dy) as usize] == player;
        let after = x + 5 * dx >= 0 && x + 5 * dx < length && y + 5 * dy >= 0 && y + 5 * dy < length && board[(x + 5 * dx) as usize][(y + 5 * dy) as usize] == player;

        if !before && !after {
            return true;
        }
    }

    false
}
