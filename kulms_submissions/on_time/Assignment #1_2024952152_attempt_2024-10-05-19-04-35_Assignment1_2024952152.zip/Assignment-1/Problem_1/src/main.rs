// ######################################################################
// Imports
// ######################################################################
use std::io::{self, BufRead};


// ######################################################################
// Global Constants
// ######################################################################
const GRADE_GPA: [(&str, f64); 9] = [
    ("F", 0.00),
    ("D0", 1.00), 
    ("D+", 1.50), 
    ("C0", 2.00), 
    ("C+", 2.50), 
    ("B0", 3.00),
    ("B+", 3.50), 
    ("A0", 4.00), 
    ("A+", 4.50), 
];


// ######################################################################
// Main Function
// ######################################################################
fn main() {
    println!("Start of program.");

    // Read all inputs until the end into buffer -> run program after
    let mut inputs = Vec::new();

    // Use stdin to read input lines
    let stdin = io::stdin();
    let handle = stdin.lock();

    for line in handle.lines() {
        let line = line.expect("Problem reading line.");

        inputs.push(line.clone());

        if line.len() == 1 {
            break;
        }
    }

    println!();

    // Setup all the necessary variables for input processing and calulations
    let mut first: bool = true;
    let mut counter: usize = 0;

    let mut num_subject: usize = 0;
    let mut min_gpa: f64 = 0.0;
    let mut total_credits: usize = 0;
    let mut weighted_gpa: f64 = 0.0;

    let mut remaining_credit: usize = 0;
    
    // Processing inputs
    for input in &inputs {
        // Get number of courses and min GPA
        if first {
            let criteria: Vec<&str>  = input.trim().split_whitespace().collect();
            num_subject = criteria[0].parse().unwrap();
            min_gpa = criteria[1].parse().unwrap();
            first = false;
        }
        // Get current average GPA
        else if counter < num_subject - 1 {
            let course: Vec<&str> = input.trim().split_whitespace().collect();
            
            println!("Course: {:?}", course);
            let credit: usize = course[0].parse().unwrap();
            let grade: &str = course[1];
            let gpa: f64 = get_gpa(grade);
            
            total_credits += credit;
            weighted_gpa += (credit as f64) * gpa;

            counter += 1;
        }
        // Get number of credit for last course
        else {
            remaining_credit = input.trim().parse().unwrap();
            total_credits += remaining_credit;
        }
    }

    // Calculate required grade
    let required_grade = required_grade(weighted_gpa, total_credits, remaining_credit, min_gpa);

    println!("{required_grade}");
}


// ######################################################################
// Helper Functions
// ######################################################################


// Rounding to 3rd 
fn round_down(num: f64) -> f64 {
    (num * 100.0 + 0.005).floor() / 100.0
}

// Get Associated Grade
// fn get_grade(gpa_search: &f64) -> &str {
//     for (grade, gpa) in GRADE_GPA {
//         if  gpa == *gpa_search {
//             return grade;
//         }
//     }
//
//     ""
// }

// Get Associated GPA
fn get_gpa(grade_search: &str) -> f64 {
    for (grade, gpa) in GRADE_GPA {
        if  grade_search == grade {
            return gpa;
        }
    }

    0.00
}


// Get Required Grade
fn required_grade(weighted_gpa: f64, total_credit: usize, remaining_credit: usize, min_gpa: f64) -> &'static str {
    for (grade, gpa) in GRADE_GPA {
        let final_avg = (gpa * (remaining_credit as f64) + weighted_gpa) / (total_credit as f64);
        let final_avg = round_down(final_avg);
        if final_avg > min_gpa {
            return grade;
        }
    }

    "impossible"
}