use std::io;

const MAX_INSTRUCTION: usize = 100000;
const MAX_STACK: usize = 1000;
const ERROR_STRING: &str = "ERROR";

fn instruction_to_num(instruction: &str) -> i32 {
    match instruction {
        "NUM" => 0,
        "POP" => 1,
        "INV" => 2,
        "DUP" => 3,
        "SWP" => 4,
        "ADD" => 5,
        "SUB" => 6,
        "MUL" => 7,
        "DIV" => 8,
        "MOD" => 9,
        "END" => 10,
        "QUIT" => 11,
        _ => -1,
    }
}

fn binary_operation_template(
    stack: &mut [i32; MAX_STACK],
    top: &mut i32,
    operation: fn(i64, i64) -> i64,
) -> Result<(), &'static str> {
    let x = pop(stack, top);
    let y = pop(stack, top);
    if x.is_ok() && y.is_ok() {
        let x = x.unwrap() as i64;
        let y = y.unwrap() as i64;
        let result = operation(x, y);
        if is_num_over_limit(result) {
            return Err(ERROR_STRING);
        }
        return push(stack, top, result as i32);
    }
    return Err(ERROR_STRING);
}

fn binary_operation_template_mod_and_div(
    stack: &mut [i32; MAX_STACK],
    top: &mut i32,
    operation: fn(i64, i64) -> i64,
) -> Result<(), &'static str> {
    let x = pop(stack, top);
    let y = pop(stack, top);
    if x.is_ok() && y.is_ok() {
        let x = x.unwrap() as i64;
        let y = y.unwrap() as i64;
        if y == 0 {
            // println!("{}",ERROR_STRING);
            return Err(ERROR_STRING);
        }
        let result = operation(x, y);
        if is_num_over_limit(result) {
            return Err(ERROR_STRING);
        }
        return push(stack, top, result as i32);
    }
    return Err(ERROR_STRING);
}

fn action_num(stack: &mut [i32; MAX_STACK], top: &mut i32, x: i32) -> Result<(), &'static str> {
    push(stack, top, x)
}

fn action_pop(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    if pop(stack, top).is_err() {
        return Err(ERROR_STRING);
    }
    return Ok(());
}

fn action_inv(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    let x = pop(stack, top);
    if x.is_ok() {
        let x = x.unwrap();
        let x = -x;
        return push(stack, top, x);
    }
    return Err(ERROR_STRING);
}

fn action_dup(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    let x = pop(stack, top);
    if x.is_ok() {
        let x = x.unwrap();
        let _ = push(stack, top, x);
        return push(stack, top, x);
    }
    return Err(ERROR_STRING);
}

fn action_swp(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    let x = pop(stack, top);
    let y = pop(stack, top);
    if x.is_ok() && y.is_ok() {
        let x = x.unwrap();
        let y = y.unwrap();
        let _ = push(stack, top, x);
        return push(stack, top, y);
    }
    return Err(ERROR_STRING);
}

fn action_add(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    binary_operation_template(stack, top, |x, y| x + y)
}

fn action_sub(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    binary_operation_template(stack, top, |x, y| x - y)
}

fn action_mul(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    binary_operation_template(stack, top, |x, y| x * y)
}

fn action_div(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    binary_operation_template_mod_and_div(stack, top, |x, y| x / y)
}

fn action_mod(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<(), &'static str> {
    binary_operation_template_mod_and_div(stack, top, |x, y| x % y)
}

fn instruction_to_action(
    instruction: i32,
    stack: &mut [i32; MAX_STACK],
    top: &mut i32,
    x: i32,
) -> Result<(), &'static str> {
    match instruction {
        0 => action_num(stack, top, x),
        1 => action_pop(stack, top),
        2 => action_inv(stack, top),
        3 => action_dup(stack, top),
        4 => action_swp(stack, top),
        5 => action_add(stack, top),
        6 => action_sub(stack, top),
        7 => action_mul(stack, top),
        8 => action_div(stack, top),
        9 => action_mod(stack, top),
        10 => Err("end"),
        _ => Err(ERROR_STRING),
    }
}
fn read_line(buf: &mut String) {
    buf.clear();
    io::stdin().read_line(buf).expect("Failed to read line");
}

fn is_num_over_limit(n: i64) -> bool {
    let n = if n < 0 { -n } else { n };
    return n > 1000000000;
}

fn print_operation_result(n: i32) {
    if is_num_over_limit(n as i64) {
        println!("{}", ERROR_STRING);
        return;
    }
    println!("{}", n);
}

// fn print_stack(stack: [i32; MAX_STACK], top: i32) {
//     for i in 0..top {
//         println!("{}", stack[i as usize]);
//     }
// }

fn is_stack_empty(top: i32) -> bool {
    return top == 0;
}

fn is_stack_full(top: i32) -> bool {
    return top == 1000;
}

fn is_stack_has_one_element(top: i32) -> bool {
    return top == 1;
}

fn push(stack: &mut [i32; MAX_STACK], top: &mut i32, x: i32) -> Result<(), &'static str> {
    if is_stack_full(*top) {
        return Err("overflow");
    }
    stack[*top as usize] = x;
    *top += 1;
    return Ok(());
}

fn pop(stack: &mut [i32; MAX_STACK], top: &mut i32) -> Result<i32, &'static str> {
    if is_stack_empty(*top) {
        return Err("underflow");
    }
    *top -= 1;
    // println!("pop : {}", stack[*top as usize]);
    return Ok(stack[*top as usize]);
}

fn clear_stack(top: &mut i32) {
    *top = 0;
}

fn simulate() -> i32 {
    let mut stack: [i32; MAX_STACK] = [-1; MAX_STACK];
    let mut top = 0;
    let mut instructions: [i32; MAX_INSTRUCTION] = [-1; MAX_INSTRUCTION];
    let mut num_instruction_arr: [i32; MAX_INSTRUCTION] = [0; MAX_INSTRUCTION];

    let mut instruction_count = 0;

    let mut buf = String::new();

    loop {
        read_line(&mut buf);

        let mut inputs = buf.trim().split_whitespace();
        let instruction = inputs.next().unwrap();
        let num_instruction = instruction_to_num(instruction);
        let mut x = 0;
        if num_instruction == 0 {
            x = inputs.next().unwrap().parse::<i32>().unwrap();
        }

        if num_instruction == 10 {
            break;
        }

        if num_instruction == 11 {
            return 1;
        }

        instructions[instruction_count] = num_instruction;
        num_instruction_arr[instruction_count] = x;

        instruction_count += 1;
    }

    read_line(&mut buf);

    let n = buf.trim().parse::<i32>().unwrap();

    for _i in 0..n {
        read_line(&mut buf);
        let cur = buf.trim().parse::<i32>().unwrap();

        clear_stack(&mut top);

        let mut flag = false;

        let _ = push(&mut stack, &mut top, cur);

        for j in 0..instruction_count {
            let instruction = instructions[j];
            let x = num_instruction_arr[j];
            // println!("instruction: {}, x: {}", instruction, x);
            let result = instruction_to_action(instruction, &mut stack, &mut top, x);
            if result.is_err() {
                println!("{}", ERROR_STRING);
                flag = true;
                break;
            }
        }

        if flag {
            continue;
        }

        if !is_stack_has_one_element(top) {
            println!("{}", ERROR_STRING);
            continue;
        }

        let result = pop(&mut stack, &mut top);
        if result.is_err() {
            println!("{}", ERROR_STRING);
            continue;
        }

        print_operation_result(result.unwrap());
    }

    read_line(&mut buf);
    return 0;
}

fn main() {
    while simulate() == 0 {}
}
