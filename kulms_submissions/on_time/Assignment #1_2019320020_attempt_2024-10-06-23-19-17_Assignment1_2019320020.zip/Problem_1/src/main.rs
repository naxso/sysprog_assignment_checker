use std::io;

fn main() {
    let grades: [&str; 9] = ["F", "D0", "D+", "C0", "C+", "B0", "B+", "A0", "A+"];
    let scores: [f32; 9] = [0.0, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5];
    let mut sum: f32 = 0.0;
    let mut credit_sum: i32 = 0;

    let mut buf = String::new();

    io::stdin()
        .read_line(&mut buf)
        .expect("Failed to read line");

    let mut inputs = buf.trim().split_whitespace();
    let n = inputs.next().unwrap().parse::<i32>().unwrap();
    let min = inputs.next().unwrap().parse::<f32>().unwrap();

    for _i in 0..n - 1 {
        buf.clear();
        io::stdin()
            .read_line(&mut buf)
            .expect("Failed to read line");

        let mut inputs = buf.trim().split_whitespace();
        let credit = inputs.next().unwrap().parse::<i32>().unwrap();
        let grade = inputs.next().unwrap();

        for j in 0..9 {
            if grade == grades[j] {
                sum += credit as f32 * scores[j];
                break;
            }
        }

        credit_sum += credit;
    }

    buf.clear();
    io::stdin()
        .read_line(&mut buf)
        .expect("Failed to read line");
    let credit2 = buf.trim().parse::<i32>().unwrap();
    credit_sum += credit2;
    let min = (min * 100.0) * credit_sum as f32;
    for i in 0..9 {
        let cur = credit2 as f32 * scores[i];
        let cur_score = (sum + cur) * 100.0;
        let cur_score = cur_score.trunc();
        let min = min as i32 / credit_sum;
        let cur_score = cur_score as i32 / credit_sum;
        if min < cur_score {
            println!("{}", grades[i]);
            return;
        }
    }
    println!("impossible");
}
