use std::io;

fn main() {
    let mut input = String::new();
    io::stdin().read_line(&mut input).unwrap();
    
    let first_line: Vec<&str> = input.trim().split_whitespace().collect();
    let n: usize = first_line[0].parse().unwrap(); 
    let x: f64 = first_line[1].parse().unwrap();   
    
    let mut total_credits = 0;
    let mut current_gpa_sum = 0.0;
    
    let grade_to_gpa = |grade: &str| -> f64 {
        match grade {
            "A+" => 4.5,
            "A0" => 4.0,
            "B+" => 3.5,
            "B0" => 3.0,
            "C+" => 2.5,
            "C0" => 2.0,
            "D+" => 1.5,
            "D0" => 1.0,
            "F" => 0.0,
            _ => 0.0,
        }
    };
    
    for _ in 0..n-1 {
        input.clear();
        io::stdin().read_line(&mut input).unwrap();
        let parts: Vec<&str> = input.trim().split_whitespace().collect();
        let credit: i32 = parts[0].parse().unwrap();
        let grade: &str = parts[1];                 
        
        total_credits += credit; 
        current_gpa_sum += credit as f64 * grade_to_gpa(grade);
    }
    
    input.clear();
    io::stdin().read_line(&mut input).unwrap();
    
    let last_credit: i32 = input.trim().parse().unwrap();
    total_credits += last_credit;
    
    let target_gpa_sum = x * total_credits as f64;
    
    let required_gpa_sum = target_gpa_sum - current_gpa_sum;
    let required_gpa = required_gpa_sum / last_credit as f64;

    let mut grades = [("A+", 4.5), ("A0", 4.0), ("B+", 3.5), ("B0", 3.0), 
                  ("C+", 2.5), ("C0", 2.0), ("D+", 1.5), ("D0", 1.0), ("F", 0.0)];

    grades.reverse();
    
    for &(grade, gpa) in &grades {
        if gpa >= required_gpa {
            println!("{}", grade);
            return;
        }
    }
    
    println!("impossible");
}
