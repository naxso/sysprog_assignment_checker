use std::collections::HashMap;
use std::io;

fn main() {
    // mapping letter grades to GPA values
    let mut gpa_map: HashMap<&str, f64> = HashMap::new();
    gpa_map.insert("A+", 4.50);
    gpa_map.insert("A0", 4.00);
    gpa_map.insert("B+", 3.50);
    gpa_map.insert("B0", 3.00);
    gpa_map.insert("C+", 2.50);
    gpa_map.insert("C0", 2.00);
    gpa_map.insert("D+", 1.50);
    gpa_map.insert("D0", 1.00);
    gpa_map.insert("F", 0.00);

    // Input the number of subjects and minimum GPA required
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read line");
    let mut input_iter = input.trim().split_whitespace();

    // Parse the number of subjects with error handling
    let num_subjects: usize = match input_iter.next().unwrap().parse() {
        Ok(n) if n > 1 => n, // Ensure number of subjects is greater than 1
        _ => {
            eprintln!("Invalid number of subjects. Must be greater than 1.");
            return;
        }
    };

    // Parse the minimum GPA required with error handling
    let min_gpa: f64 = match input_iter.next().unwrap().parse() {
        Ok(g) if g >= 0.0 && g <= 4.5 => g, // Ensure GPA is within valid range
        _ => {
            eprintln!("Invalid GPA input. Must be between 0.0 and 4.5.");
            return;
        }
    };

    let mut total_credits = 0;
    let mut total_gpa = 0.0;

    // Input credits and grade for the first n-1 subjects
    for _ in 0..(num_subjects - 1) {
        input.clear();
        io::stdin().read_line(&mut input).expect("Failed to read line");
        let mut parts = input.trim().split_whitespace();

        // Parse credits with error handling
        let credits: i32 = match parts.next().unwrap().parse() {
            Ok(c) if c > 0 => c, // Ensure positive credits
            _ => {
                eprintln!("Invalid credits input. Must be a positive integer.");
                return;
            }
        };

        // Parse grade and handle invalid grades
        let grade = parts.next().unwrap();
        let gpa = match gpa_map.get(grade) {
            Some(&g) => g,
            None => {
                eprintln!("Invalid grade input: {}. Allowed grades are A+, A0, B+, B0, C+, C0, D0, F.", grade);
                return;
            }
        };

        total_credits += credits;
        total_gpa += credits as f64 * gpa;
    }

    // Input only credits for the final subject
    input.clear();
    io::stdin().read_line(&mut input).expect("Failed to read line");
    let final_credits: i32 = match input.trim().parse() {
        Ok(c) if c > 0 => c,
        _ => {
            eprintln!("Invalid final subject credits. Must be a positive integer.");
            return;
        }
    };

    total_credits += final_credits;

    // Create a vector of tuples (grades, GPA values) and sort it in ascending order by GPA
    let mut grade_vec: Vec<(&str, f64)> = gpa_map.into_iter().collect();
    grade_vec.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    // Flag to check if exceeding is possible
    let mut exceed_found = false;

    // Iterate over the grades from the lowest (F) upwards
    for (grade, gpa) in grade_vec {
        // Calculate the new total GPA if the remaining subject has this grade
        let new_gpa = (total_gpa + final_credits as f64 * gpa) / total_credits as f64;

        // Round the GPA to three decimal places
        let rounded_gpa = (new_gpa * 1000.0).round() / 1000.0;

        // Check if this GPA exceeds the minimum GPA (it must strictly exceed it)
        if rounded_gpa > min_gpa {
            println!("{}", grade);
            exceed_found = true;
            break;
        }
    }

    // If no grade exceeds the criteria, print "impossible"
    if !exceed_found {
        println!("impossible");
    }
}

