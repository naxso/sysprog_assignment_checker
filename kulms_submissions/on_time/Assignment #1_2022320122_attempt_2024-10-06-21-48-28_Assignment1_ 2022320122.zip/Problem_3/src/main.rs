use std::io;

#[derive(PartialEq)]
enum Culinary {
    Black,
    White,
    Cook
}

fn check_win(matrix : &Vec<Vec<Culinary>>, (r, c) : (i32, i32)) -> &Culinary {
    let (r, c) = (r as usize, c as usize);
    let pos_val = &matrix[r][c];
    match pos_val {
        Culinary::Cook => { &Culinary::Cook }
        _ => {
            let mut res : &Culinary = &Culinary::Cook;

            //hor
            if c <= 14 {
                if &matrix[r][c + 1] == pos_val &&
                    &matrix[r][c + 2] == pos_val &&
                    &matrix[r][c + 3] == pos_val &&
                    &matrix[r][c + 4] == pos_val &&
                    (c == 14 || &matrix[r][c + 5] != pos_val) &&
                    (c == 0 || &matrix[r][c - 1] != pos_val) {
                    res = pos_val;
                }
            }

            //ver
            if r <= 14 {
                if &matrix[r + 1][c] == pos_val &&
                    &matrix[r + 2][c] == pos_val &&
                    &matrix[r + 3][c] == pos_val &&
                    &matrix[r + 4][c] == pos_val &&
                    (r == 14 || &matrix[r + 5][c] != pos_val) && 
                    (r == 0 || &matrix[r - 1][c] != pos_val) {
                    res = pos_val;
                }
            }

            //diag left
            if r <= 14 && c >= 4 {
                if &matrix[r + 1][c - 1] == pos_val &&
                    &matrix[r + 2][c - 2] == pos_val &&
                    &matrix[r + 3][c - 3] == pos_val &&
                    &matrix[r + 4][c - 4] == pos_val &&
                    (r == 14 || c == 4 || &matrix[r + 5][c - 5] != pos_val) &&
                    (r == 0 || c == 18 || &matrix[r - 1][c + 1] != pos_val) {
                    res = pos_val;
                }
            }

            //diag right
            if r <= 14 && c <= 14 {
                if &matrix[r + 1][c + 1] == pos_val &&
                    &matrix[r + 2][c + 2] == pos_val &&
                    &matrix[r + 3][c + 3] == pos_val &&
                    &matrix[r + 4][c + 4] == pos_val &&
                    (r == 14 || c == 14 || &matrix[r + 5][c + 5] != pos_val) &&
                    (r == 0 || c == 0 || &matrix[r - 1][c - 1] != pos_val) {
                    res = pos_val;
                }
            }

            res
        }
    }
}

fn main() {
    let mut matrix : Vec<Vec<Culinary>> = Vec::new();
    for _ in 0..19 {
        let mut s = String::new();
        io::stdin().read_line(&mut s).expect("Error while input");

        let it = s.trim().split_whitespace();
        let mut submatrix : Vec<Culinary> = Vec::new();
        for i in it {
            let i : i32 = i.parse().unwrap();
            let cul : Culinary = match i {
                0 => Culinary::Cook,
                1 => Culinary::Black,
                2 => Culinary::White,
                _ => { panic!("impossible") }
            };
            submatrix.push(cul);
        }
        matrix.push(submatrix);
    }

    let mut undecided : bool = true;
    for i in 0..19 {
        for j in 0..19 {
            match check_win(&matrix, (i, j)) {
                Culinary::Cook => {
                    continue;
                }
                Culinary::Black => {
                    undecided = false;
                    let (i, j) = (i + 1, j + 1);

                    println!("1");
                    println!("{i} {j}");
                    break;
                }
                Culinary::White => {
                    undecided = false;
                    let (i, j) = (i + 1, j + 1);

                    println!("2");
                    println!("{i} {j}");
                    break;
                }
            }
        }
        if undecided {
            continue;
        } else {
            break;
        }
    }

    if undecided {
        println!("0");
    }
}
