use std::io;

const MAX_VAL : i32 = 1000000000;

fn execute_pgm(pgm : &Vec<String>, value : i32) -> (Vec<i32>, bool) {
    let mut res : Vec<i32> = Vec::new();
    let mut well_ended : bool = true;
    res.push(value);

    for inst in pgm {
        let name = &inst[0..3];
        match name {
            "NUM" => {
                let pushval : i32 = (&inst[4..]).to_string().trim().parse().unwrap();
                res.push(pushval);
            },
            "POP" => {
                if let Some(_) = res.pop() {

                } else {
                    well_ended = false;
                    break;
                }
            }
            "INV" => {
                if let Some(x) = res.pop() {
                    res.push(-x);
                } else {
                    well_ended = false;
                    break;
                }
            }
            "DUP" => {
                if let Some(x) = res.pop() {
                    res.push(x);
                    res.push(x);
                } else {
                    well_ended = false;
                    break;
                }
            }
            "SWP" => {
                if let Some(x) = res.pop() {
                    if let Some(y) = res.pop() {
                        res.push(y);
                        res.push(x);
                    } else {
                        well_ended = false;
                        break;
                    }
                } else {
                    well_ended = false;
                    break;
                }
            }      
            "ADD" => {
                if let Some(x) = res.pop() {
                    if let Some(y) = res.pop() {
                        let calced : i32 = y.wrapping_add(x);
                        if calced.abs() > MAX_VAL {
                            well_ended = false;
                            break;
                        } else {
                            res.push(calced);
                        }
                    } else {
                        well_ended = false;
                        break;
                    }
                } else {
                    well_ended = false;
                    break;
                }
            }  
            "SUB" => {
                if let Some(x) = res.pop() {
                    if let Some(y) = res.pop() {
                        let calced : i32 = y.wrapping_sub(x);
                        if calced.abs() > MAX_VAL {
                            well_ended = false;
                            break;
                        } else {
                            res.push(calced);
                        }
                    } else {
                        well_ended = false;
                        break;
                    }
                } else {
                    well_ended = false;
                    break;
                }
            }  
            "MUL" => {
                if let Some(x) = res.pop() {
                    if let Some(y) = res.pop() {
                        let calced : i32 = y.wrapping_mul(x);
                        if calced.abs() > MAX_VAL {
                            well_ended = false;
                            break;
                        } else {
                            res.push(calced);
                        }
                    } else {
                        well_ended = false;
                        break;
                    }
                } else {
                    well_ended = false;
                    break;
                }
            }  
            "DIV" => {
                if let Some(x) = res.pop() {
                    if let Some(y) = res.pop() {
                        if x == 0 {
                            well_ended = false;
                            break;
                        } else {
                            let calced : i32 = y.abs() / x.abs();
                            if (x < 0 && y > 0) || (x > 0 && y < 0) {
                                res.push(-calced)
                            } else {
                                res.push(calced);
                            }
                        }
                    } else {
                        well_ended = false;
                        break;
                    }
                } else {
                    well_ended = false;
                    break;
                }
            }  
            "MOD" => {
                if let Some(x) = res.pop() {
                    if let Some(y) = res.pop() {
                        if x == 0 {
                            well_ended = false;
                            break;
                        } else {
                            let calced : i32 = y.abs() % x.abs();
                            if y < 0 {
                                res.push(-calced)
                            } else {
                                res.push(calced);
                            }
                        }
                    } else {
                        well_ended = false;
                        break;
                    }
                } else {
                    well_ended = false;
                    break;
                }
            }  
            _ => { panic!("impossible") }
        }
    }
    (res, well_ended)
}

fn main() {
    loop {
        let mut s = String::new();
        io::stdin().read_line(&mut s).expect("Error while input");
        s = s.trim().to_string();

        if s == "QUIT" {
            break;
        } else if s == "" {
            continue;
        } else {
            let mut pgm : Vec<String> = Vec::new();
            if s != "END" {
                pgm.push(s);
                loop {
                    let mut s = String::new();
                    io::stdin().read_line(&mut s).expect("Error while input");
                    s = s.trim().to_string();

                    if s == "END" {
                        break;
                    } else {
                        pgm.push(s);
                    }
                }
            }
        
            let mut s = String::new();
            io::stdin().read_line(&mut s).expect("Error while input");
            let n : i32 = s.trim().parse().unwrap();
            for _ in 0..n {
                let mut s = String::new();
                io::stdin().read_line(&mut s).expect("Error while input");
                let v : i32 = s.trim().parse().unwrap();
                let (res, well_ended) = execute_pgm(&pgm, v);
                if res.len() == 1 && well_ended {
                    let Some(res_val) = res.first() else { panic!("impossible") };
                    println!("{res_val}");
                } else {
                    println!("ERROR");
                }
            }
            println!("");
        }
    }
}
