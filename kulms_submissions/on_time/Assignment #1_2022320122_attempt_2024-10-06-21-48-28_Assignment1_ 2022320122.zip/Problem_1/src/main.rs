use std::io;

fn letter_to_grade(letter : &str) -> i32 {
    match letter {
        "A+" => 450,
        "A0" => 400,
        "B+" => 350,
        "B0" => 300,
        "C+" => 250,
        "C0" => 200,
        "D+" => 150,
        "D0" => 100,
        "F" => 0,
        _ => panic!("Hakjeom letter is wrong")
    }
}

fn get_needed_grade(need_gpa : i32, l : i32, sum : i32) -> String {
    {
        if need_gpa == 0 || need_gpa <= 0 - sum { "F" }
        else if need_gpa == 100 * l || need_gpa <= 100 * l - sum { "D0" }
        else if need_gpa == 150 * l || need_gpa <= 150 * l - sum { "D+" }
        else if need_gpa == 200 * l || need_gpa <= 200 * l - sum { "C0" }
        else if need_gpa == 250 * l || need_gpa <= 250 * l - sum { "C+" }
        else if need_gpa == 300 * l || need_gpa <= 300 * l - sum { "B0" }
        else if need_gpa == 350 * l || need_gpa <= 350 * l - sum { "B+" }
        else if need_gpa == 400 * l || need_gpa <= 400 * l - sum { "A0" }
        else if need_gpa == 450 * l || need_gpa <= 450 * l - sum { "A+" }
        else { "impossible" }
    }.to_string()
}

fn main() {
    let mut s = String::new();
    io::stdin().read_line(&mut s).expect("Error while input");

    let mut it = s.trim().split_whitespace();
    let n : i32 = it.next().unwrap().parse().unwrap();
    let x : f64 = it.next().unwrap().parse().unwrap();
    let x : i32 = (x * 100.0) as i32;

    let mut vec : Vec<(i32, i32)> = Vec::new();
    for _ in 1..n {
        let mut s = String::new();
        io::stdin().read_line(&mut s).expect("Error while input");
        let mut it = s.trim().split_whitespace();
        let c : i32 = it.next().unwrap().parse().unwrap();
        let g : i32 = letter_to_grade(it.next().unwrap());
        vec.push((c, g));
    }

    let mut s = String::new();
    io::stdin().read_line(&mut s).expect("Error while input");
    let l : i32 = s.trim().parse().unwrap();

    let gpa : i32 = vec.iter().fold(0, |acc, (c, g)| acc + c * g);
    let sum : i32 = vec.iter().fold(0, |acc, (c, _)| acc + c) + l;
    let need_gpa : i32 = x * sum - gpa;
    let res = get_needed_grade(need_gpa, l, sum);
    println!("{res}");
}