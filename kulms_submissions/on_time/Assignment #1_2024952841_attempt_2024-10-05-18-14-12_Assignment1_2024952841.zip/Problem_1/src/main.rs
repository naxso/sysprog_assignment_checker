use std::collections::HashMap;
use std::io;

fn main() {

    let grades: HashMap<String, f64> = HashMap::from([
        (String::from("A+"), 4.50),
        (String::from("A0"), 4.00),
        (String::from("B+"), 3.50),
        (String::from("B0"), 3.00),
        (String::from("C+"), 2.50),
        (String::from("C0"), 2.00),
        (String::from("D+"), 1.50),
        (String::from("D0"), 1.00),
        (String::from("F") , 0.00),
    ]);

    // Parse input
    let mut input_line = String::new();
    io::stdin().read_line(&mut input_line)
        .expect("Failed to read line");

    let parts: Vec<&str> = input_line.trim().split_whitespace().collect();
    let grades_total: usize = parts[0].parse().expect("Invalid total number of grades");
    let req_gpa: f64 = parts[1].parse().expect("Invalid minimum GPA");

    let mut recv_grades: Vec<(u32, f64)> = vec![];
    for _ in 1..grades_total {
        let mut input_line = String::new();
        io::stdin().read_line(&mut input_line)
            .expect("Failed to read line");

        let parts: Vec<&str> = input_line.trim().split_whitespace().collect();
        let credits: u32 = parts[0].parse().expect("Invalid credits value");
        let grade: String = parts[1].parse().expect("Invalid grade value");
        if let Some(&grade_value) = grades.get(&grade) {
            recv_grades.push((credits, grade_value));
        } else {
            eprintln!("Invalid Grade value! Grade value not found");
        }
    }

    let mut input_line = String::new();
    io::stdin()
        .read_line(&mut input_line)
        .expect("Failed to read line");

    let new_grade_credits: u32 = input_line.trim().parse().expect("Invalid new grade credit value");

    /*
     - calculate the new GPA for each grade with given credit value
     - rounded down to the third decimal place
     - start from the worst if found possible grade return grade
     - otherwise return "impossible"
    */
    let mut min_grade = String::from("impossible");
    for string_grade in ["F", "D0", "D+", "C0", "C+", "B0", "B+","A0", "A+"] {
        recv_grades.push((new_grade_credits, grades[string_grade]));
        let calculated_gpa = calc_gpa(&recv_grades);
        if calculated_gpa > req_gpa {
            min_grade = String::from(string_grade);
            break;
        }
        recv_grades.pop();
    }
    // Print result
    println!("{}", min_grade);
}

fn calc_gpa(recv_grades: &Vec<(u32, f64)>) -> f64 {
    let mut sum: f64 = 0.00;
    let mut credits_total: f64 = 0.00;
    for (credits, grade) in recv_grades {
        sum += grade * *credits as f64;
        credits_total += *credits as f64;
    }
    ((sum * 100.00) / credits_total).floor() / 100.0
}