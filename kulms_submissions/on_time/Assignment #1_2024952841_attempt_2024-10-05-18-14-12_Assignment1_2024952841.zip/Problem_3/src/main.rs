use std::io;

#[derive(Clone, Copy)]
enum Player {NoPlayer, Black, White}
const DIR_MOVES: [(i8, i8); 4] = [(1, 0), (1, 1), (0, 1), (-1, 1)];
const SIZE: usize = 19;
const WIN_NUM: u8 = 5;

struct OmokBoard {
    board: [[u8; SIZE]; SIZE]
}

impl OmokBoard {
    fn init() -> Self {
        Self {
            board: [[0; SIZE]; SIZE],
        }
    }

    fn fill_board(&mut self) {
        for row in 0..SIZE {
            let mut input = String::new();
            io::stdin()
                    .read_line(&mut input)
                    .expect("Failed to read line");
             for (col, piece_str) in input.split_whitespace().enumerate() {
                self.board[row][col] = piece_str.parse().expect("Invalid number on input");
            }
        }
    }

    fn is_present(&self, row: usize, col: usize, player: Player) -> bool {
        if !Self::is_in_bounds(row, col, (0, 0)) {
            return false
        }
        self.board[row][col] == player as u8
    }

    fn is_empty(&self, row: usize, col: usize) -> bool {
        self.board[row][col] == Player::NoPlayer as u8
    }

    fn get_player(&self, row: usize, col: usize) -> Option<Player> {
        match self.board[row][col] {
            0 => Some(Player::NoPlayer),
            1 => Some(Player::Black),
            2 => Some(Player::White),
            _ => None,
        }
    }

    fn is_in_bounds(row: usize, col: usize, dir: (i8, i8)) -> bool {
        let new_row = row as i8 + dir.0;
        let new_col = col as i8 + dir.1;

        new_row >= 0 && new_row < SIZE as i8 && new_col >= 0 && new_col < SIZE as i8
    }

    fn search_dirs(&self, row: usize, col: usize, player: Player) -> bool {
        for dir in DIR_MOVES {
            let mut curr_row = row;
            let mut curr_col = col;
            let mut counter = 0;

            while self.is_present(curr_row, curr_col, player) {
                counter += 1;
                if !Self::is_in_bounds(curr_row, curr_col, dir) {
                    break
                }
                curr_row = (curr_row as i8 + dir.0) as usize;
                curr_col = (curr_col as i8 + dir.1) as usize;
            }

            let mut curr_row = row;
            let mut curr_col = col;
            counter -= 1;
            while self.is_present(curr_row, curr_col, player) {
                counter += 1;
                if !Self::is_in_bounds(curr_row, curr_col, (-dir.0, -dir.1)) {
                    break
                }
                curr_row = (curr_row as i8 - dir.0) as usize;
                curr_col = (curr_col as i8 - dir.1) as usize;
            }
            if counter == WIN_NUM {
                return true
            }
        }
        false
    }

    fn is_win(&self, row: usize, col: usize) -> bool {
        if self.is_empty(row, col) {
            return false
        }

        if let Some(player) = self.get_player(row, col) {
            self.search_dirs(row, col, player)
        } else {
            println!("Invalid value on the board");
            false
        }


    }
}

fn main() {
    let mut board = OmokBoard::init();
    board.fill_board();

    for row in 0..SIZE {
        for col in 0..SIZE {
            if !board.is_empty(row, col) {
                if board.is_win(row, col) {
                    if let Some(winner) = board.get_player(row, col) {
                        println!("{}", winner as u8);
                        println!("{} {}", row+1, col+1);
                        std::process::exit(0);
                    }
                }
            }
        }
    }
    println!("0");
}
