use std::io;

const STACK_MAX_SIZE: usize = 1000;
const MAX_NUM: i64 = 1_000_000_000;
struct Commands {
    list: Vec<String>,
}

impl Commands {
    fn new() -> Self {
        Self {
            list: Vec::new(),
        }
    }

    fn add(&mut self, command: &str) {
        self.list.push(command.parse().unwrap());
    }

    fn empty(&mut self) {
        self.list.clear();
    }
}

struct StackCalculator {
    stack: [i64; STACK_MAX_SIZE],
    top_idx: usize,
}

impl StackCalculator {
    fn new() -> Self {
        Self {
           stack: [0; STACK_MAX_SIZE],
           top_idx: 0,
        }
    }

    fn empty(&mut self) {
        self.stack.fill(0);
        self.top_idx = 0;
    }

    fn num(&mut self, num: i64) -> Result<(), ()> {
        if num.abs() > MAX_NUM || self.top_idx == STACK_MAX_SIZE {
            return Err(());
        }
        self.stack[self.top_idx] = num;
        self.top_idx += 1;
        Ok(())
    }

    fn pop(&mut self) -> Result<(), ()> {
        if self.top_idx <= 0 {
            return Err(());
        }
        self.top_idx -= 1;
        self.stack[self.top_idx] = 0;
        Ok(())
    }

    fn inv(&mut self) -> Result<(), ()> {
        if self.top_idx <= 0 {
            return Err(());
        }
        self.stack[self.top_idx - 1] = -1 * self.stack[self.top_idx - 1];
        Ok(())
    }

    fn dup(&mut self) -> Result<(), ()> {
        if self.top_idx == STACK_MAX_SIZE {
            return Err(());
        }
        self.stack[self.top_idx] = self.stack[self.top_idx - 1];
        self.top_idx += 1;
        Ok(())
    }

    fn swp(&mut self) -> Result<(), ()> {
        if self.top_idx <= 1 {
            return Err(());
        }
        let tmp = self.stack[self.top_idx - 2];
        self.stack[self.top_idx - 2] = self.stack[self.top_idx - 1];
        self.stack[self.top_idx - 1] = tmp;
        Ok(())
    }

    fn add(&mut self) -> Result<(), ()> {
        if self.top_idx <= 1 {
            return Err(());
        }
        let result = self.stack[self.top_idx - 2] + self.stack[self.top_idx - 1];
        if result.abs() > MAX_NUM {
            return Err(());
        }
        self.stack[self.top_idx - 2] = result;
        self.pop()
    }

    fn sub(&mut self) -> Result<(), ()> {
        if self.top_idx <= 1 {
            return Err(());
        }
        let result = self.stack[self.top_idx - 2] - self.stack[self.top_idx - 1];
        if result.abs() > MAX_NUM {
            return Err(());
        }
        self.stack[self.top_idx - 2] = result;
        self.pop()
    }

    fn mul(&mut self) -> Result<(), ()> {
        if self.top_idx <= 1 {
            return Err(());
        }
        let result = self.stack[self.top_idx - 2] * self.stack[self.top_idx - 1];
        if result.abs() > MAX_NUM {
            return Err(());
        }
        self.stack[self.top_idx - 2] = result;
        self.pop()
    }

    fn div(&mut self) -> Result<(), ()> {
        if self.top_idx <= 1 || self.stack[self.top_idx - 1] == 0 {
            return Err(());
        }
        let result = self.stack[self.top_idx - 2].abs() / self.stack[self.top_idx - 1].abs();
        if result > MAX_NUM {
            return Err(());
        }
        let result = match (self.stack[self.top_idx - 2] < 0, self.stack[self.top_idx - 1] < 0) {
            (true, true) => result,
            (false, false) => result,
            (_, _) => -1 * result,
        };
        self.stack[self.top_idx - 2] = result;
        self.pop()
    }

    fn modulo(&mut self) -> Result<(), ()> {
        if self.top_idx <= 1 || self.stack[self.top_idx - 1] == 0 {
            return Err(());
        }
        let result = self.stack[self.top_idx - 2].abs() % self.stack[self.top_idx - 1].abs();
        if result > MAX_NUM {
            return Err(());
        }
        let result = match (self.stack[self.top_idx - 2] < 0, self.stack[self.top_idx - 1] < 0) {
            (true, _) => -1 * result,
            (false, _) => result,
        };
        self.stack[self.top_idx - 2] = result;
        self.pop()
    }

    fn print_result(&self) {
        if self.top_idx == 1 {
            println!("{}", self.stack[0]);
        } else {
            println!("ERROR");
        }
    }
}

fn main() {

    let mut commands = Commands::new();
    let mut stack_calc = StackCalculator::new();

   'main_loop: loop {
        loop {
            let mut input_line = String::new();
            io::stdin().read_line(&mut input_line).expect("Failed to read line");

            let input: String = input_line.parse().expect("Invalid command");
            let trimmed_input = input.trim();
            if trimmed_input.is_empty() {
                break
            }

            if trimmed_input == "QUIT" {
                break 'main_loop;
            }

            if trimmed_input == "END" {
                break;
            }

            commands.add(trimmed_input);
        }

        let mut input_line = String::new();
        io::stdin().read_line(&mut input_line)
        .expect("Failed to read line");
        let num_exec = input_line.trim().parse().expect("Invalid number of iterations");

        'exec_loop: for _ in 0..num_exec {
            stack_calc.empty();
            let mut input_line = String::new();
            io::stdin().read_line(&mut input_line)
            .expect("Failed to read line");

            let input_num: i64 = input_line
                .trim()
                .parse()
                .expect("Invalid input! Please enter a valid integer.");

            if let Err(()) = stack_calc.num(input_num) {
                println!("ERROR");
                std::process::exit(1);
            }

            for command in commands.list.iter() {
                match command.as_str() {
                    command if command.starts_with("NUM") => {
                        let parts: Vec<&str> = command.split_whitespace().collect();
                        if let Err(()) = stack_calc.num(parts[1].parse::<i64>().expect("Invalid number for command NUM")) {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    }
                    "POP" => {
                        if let Err(()) = stack_calc.pop() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "INV" => {
                        if let Err(()) = stack_calc.inv() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "DUP" => {
                        if let Err(()) = stack_calc.dup() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "SWP" => {
                        if let Err(()) = stack_calc.swp() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "ADD" => {
                        if let Err(()) = stack_calc.add() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "SUB" => {
                        if let Err(()) = stack_calc.sub() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "MUL" => {
                        if let Err(()) = stack_calc.mul() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "DIV" => {
                        if let Err(()) = stack_calc.div() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    "MOD" => {
                        if let Err(()) = stack_calc.modulo() {
                            println!("ERROR");
                            continue 'exec_loop;
                        }
                    },
                    _ => {
                        println!("ERROR");
                        continue 'exec_loop;
                    },
                }
            }
            stack_calc.print_result();
        }
       commands.empty();
       println!();
        let mut input_line = String::new();
            io::stdin().read_line(&mut input_line)
            .expect("Failed to read line");
   }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ok() {
        let mut stack_calc = StackCalculator::new();
        stack_calc.num(1).unwrap();
        stack_calc.num(6).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
        stack_calc.num(6).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
    }

    #[test]
    fn test_error() {
        let mut stack_calc = StackCalculator::new();

        assert_eq!(stack_calc.pop(), Err(()));


        // Division by 0
        stack_calc.num(6).unwrap();
        stack_calc.num(0).unwrap();
        assert_eq!(stack_calc.div(), Err(()));
        stack_calc.pop().unwrap();

        // Not enough values
        stack_calc.num(1).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
        assert_eq!(stack_calc.div(), Err(()));

        // Value exceeds maximum
        stack_calc.num(MAX_NUM).unwrap();
        assert_eq!(stack_calc.add(), Err(()));
    }

    #[test]
        fn test_div_sign() {
        let mut stack_calc = StackCalculator::new();
        stack_calc.num(6).unwrap();
        stack_calc.num(-1).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], -6);
        stack_calc.num(-6).unwrap();
        stack_calc.num(1).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], -6);
        stack_calc.num(-6).unwrap();
        stack_calc.num(-1).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], 6);
        stack_calc.num(6).unwrap();
        stack_calc.num(1).unwrap();
        assert_eq!(stack_calc.div(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], 6);
    }

    #[test]
    fn test_mod_sign() {
        let mut stack_calc = StackCalculator::new();
        stack_calc.num(9).unwrap();
        stack_calc.num(-2).unwrap();
        assert_eq!(stack_calc.modulo(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], 1);
        stack_calc.num(-9).unwrap();
        stack_calc.num(2).unwrap();
        assert_eq!(stack_calc.modulo(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], -1);
        stack_calc.num(-9).unwrap();
        stack_calc.num(-2).unwrap();
        assert_eq!(stack_calc.modulo(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], -1);
        stack_calc.num(9).unwrap();
        stack_calc.num(2).unwrap();
        assert_eq!(stack_calc.modulo(), Ok(()));
        assert_eq!(stack_calc.stack[stack_calc.top_idx-1], 1);
    }
}
