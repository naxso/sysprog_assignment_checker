fn main()  {
    let x =5;
    println!("x value {}", x);
    x=10;
}