use std::io;

fn main() {
    println!("과목 수와 목표 학점을 띄어쓰기 하여 입력하세요. (ex. 5 3.59)");
    let mut input: String = String::new(); // 변수 타입과 함께 선언

    io::stdin()
        .read_line(&mut input)
        .expect("입력 실패");

    let mut sliced = input.split_whitespace();

    let credit = if let Some(credit_str) = sliced.next() {
        let credit = credit_str.parse::<i64>().unwrap(); 
        if credit < 2 || credit > 24 {
            println!("2에서 24 사이의 과목 수를 입력하세요.");
            return;
        }
        credit
    } else {
        println!("입력하지 않았습니다.");
        return;
    };

    let target_gpa = if let Some(gpa_str) = sliced.next() {
        let gpa = gpa_str.parse::<f64>().unwrap(); 
        if gpa < 0.0 || gpa > 4.5 {
            println!("목표 학점은 0과 4.5 사이여야 합니다.");
            return;
        }
        gpa+0.01
    } else {
        println!("입력하지 않았습니다.");
        return;
    };

    let mut total_credits = Vec::new();
    let mut total_grades = Vec::new();

    for i in 0..(credit - 1) {
        println!("{}번째 과목의 학점과 등급 입력 (ex.4 A+)", i + 1);

        let mut grade_input = String::new();
        io::stdin()
            .read_line(&mut grade_input)
            .expect("입력 실패");

        let mut sliced = grade_input.split_whitespace();

        if let Some(credit_2_str) = sliced.next() {
            let credit_2 = credit_2_str.parse::<i64>().unwrap(); 
            total_credits.push(credit_2);
        } else {
            println!("입력하지 않았습니다.");
            return;
        };

        if let Some(grade_str) = sliced.next() {
            let grade: f64 = match grade_str {
                "A+" => 4.5,
                "A0" => 4.0,
                "B+" => 3.5,
                "B0" => 3.0,
                "C+" => 2.5,
                "C0" => 2.0,
                "D+" => 1.5,
                "D0" => 1.0,
                "F" => 0.0,
                _ => {
                    println!("잘못되었습니다.");
                    return;
                }
            };
            total_grades.push(grade);
        } else {
            println!("입력하지 않았습니다.");
            return;
        }
    }

    let mut final_credit_input = String::new();
    println!("마지막 과목의 학점을 입력하세요. ");
    io::stdin()
        .read_line(&mut final_credit_input)
        .expect("입력 실패");

    let final_credit: i64 = final_credit_input.trim().parse().expect("변환 실패");

    let credits_sum: i64 = total_credits.iter().sum();
    let grades_sum: f64 = total_credits.iter()
        .zip(total_grades.iter())
        .map(|(&c, &g)| c as f64 * g)
        .sum();

    let required_grade = (target_gpa * (credits_sum + final_credit) as f64 - grades_sum) / final_credit as f64;

    if required_grade >4.5 {
        println!("목표 GPA를 달성할 수 없습니다.");
        return;
    }

    let required_grade_str = match required_grade {
        r if r > 4.0 => "A+",
        r if r > 3.5 => "A0",
        r if r > 3.0 => "B+",
        r if r > 2.5 => "B0",
        r if r > 2.0 => "C+",
        r if r > 1.5 => "C0",
        r if r > 1.0 => "D+",
        r if r > 0.0 => "D0",
        _ => "F",
    };

    println!("마지막 과목에서 필요한 등급: {}", required_grade_str);
}
